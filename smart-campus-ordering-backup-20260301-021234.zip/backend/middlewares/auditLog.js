const AuditLog = require('../models/AuditLog');

module.exports = (action, entityType) => {
  return async (req, res, next) => {
    try {
      const log = new AuditLog({
        action,
        entityType,
        entityId: req.params.id,
        performedBy: req.user.id,
        metadata: req.body,
        ipAddress: req.ip,
        userAgent: req.get('User-Agent')
      });
      
      await log.save();
    } catch (err) {
      console.error('Audit logging failed:', err);
    }
    next();
  };
};