const express = require('express');
const router = express.Router();
const { auth } = require('../middlewares/auth');
const { 
  createOrder, 
  updateOrderStatus, 
  getStudentOrders 
} = require('../controllers/orderController');

// Verify controller functions exist
if (!createOrder) throw new Error('createOrder controller is not defined!');
if (!updateOrderStatus) throw new Error('updateOrderStatus controller is not defined!');
if (!getStudentOrders) throw new Error('getStudentOrders controller is not defined!');

// @route   POST /api/orders
// @desc    Create new order
// @access  Private (Student)
router.post('/', auth, createOrder);

// @route   PUT /api/orders/:id
// @desc    Update order status
// @access  Private (Vendor)
router.put('/:id', auth, updateOrderStatus);

// @route   GET /api/orders/student
// @desc    Get student orders
// @access  Private (Student)
router.get('/student', auth, getStudentOrders);

module.exports = router;