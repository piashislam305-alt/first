const orderController = require('./controllers/orderController');

console.log('Testing controller:');
console.log('createOrder:', typeof orderController.createOrder);
console.log('updateOrderStatus:', typeof orderController.updateOrderStatus);
console.log('getStudentOrders:', typeof orderController.getStudentOrders);