const mongoose = require("mongoose");

const OrderSchema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  vendorId: { type: mongoose.Schema.Types.ObjectId, ref: "Vendor", required: true },
  items: [
    {
      menuItemId: { type: mongoose.Schema.Types.ObjectId, ref: "MenuItem" },
      quantity: { type: Number, default: 1 },
    },
  ],
  total: { type: Number, required: true },
  status: { 
    type: String, 
    enum: ["pending", "preparing", "ready", "shipped", "completed", "cancelled"], 
    default: "pending" 
  },
  paymentStatus: { type: String, enum: ["pending", "completed", "failed"], default: "pending" },
}, { timestamps: true });

module.exports = mongoose.model("Order", OrderSchema);