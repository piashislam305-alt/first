const mongoose = require('mongoose');

const AdminSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  permissions: {
    manageUsers: { type: Boolean, default: true },
    manageVendors: { type: Boolean, default: true },
    viewAnalytics: { type: Boolean, default: true }
  },
  twoFASecret: String,
  twoFAEnabled: { type: Boolean, default: false },
  lastActiveAt: Date,
  lastIpAddress: String,
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Admin', AdminSchema);