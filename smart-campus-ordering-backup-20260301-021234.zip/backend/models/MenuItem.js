const mongoose = require("mongoose");

const MenuItemSchema = new mongoose.Schema({
  vendorId: { type: mongoose.Schema.Types.ObjectId, ref: "Vendor", required: true },
  name: { type: String, required: true },
  price: { type: Number, required: true, min: 0 },
  category: { type: String, default: "Uncategorized" },
  description: { type: String, default: "" },
  image: { type: String, default: "" },
  isAvailable: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model("MenuItem", MenuItemSchema);