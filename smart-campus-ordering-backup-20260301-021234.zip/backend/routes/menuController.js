const MenuItem = require("../models/MenuItem");

// Add new menu item
exports.addMenuItem = async (req, res) => {
  try {
    const { name, price, category, description } = req.body;
    
    if (!name || !price) {
      return res.status(400).json({ error: "Name and price are required" });
    }
    
    const newItem = new MenuItem({
      vendorId: req.user.id,
      name,
      price: parseFloat(price),
      category: category || "Uncategorized",
      description: description || ""
    });
    
    await newItem.save();
    res.status(201).json(newItem);
  } catch (err) {
    console.error("Error adding item:", err.message);
    res.status(500).json({ error: "Failed to add item!" });
  }
};

// Update menu item
exports.updateMenuItem = async (req, res) => {
  try {
    const updatedItem = await MenuItem.findOneAndUpdate(
      { _id: req.params.id, vendorId: req.user.id },
      req.body,
      { new: true }
    );
    
    if (!updatedItem) {
      return res.status(404).json({ error: "Item not found!" });
    }
    
    res.json(updatedItem);
  } catch (err) {
    console.error("Error updating item:", err.message);
    res.status(500).json({ error: "Update failed!" });
  }
};

// Delete menu item
exports.deleteMenuItem = async (req, res) => {
  try {
    const deletedItem = await MenuItem.findOneAndDelete({
      _id: req.params.id,
      vendorId: req.user.id
    });
    
    if (!deletedItem) {
      return res.status(404).json({ error: "Item not found!" });
    }
    
    res.json({ message: "Item deleted!" });
  } catch (err) {
    console.error("Error deleting item:", err.message);
    res.status(500).json({ error: "Deletion failed!" });
  }
};

// Get vendor's menu
exports.getVendorMenu = async (req, res) => {
  try {
    const menu = await MenuItem.find({ vendorId: req.user.id });
    res.json(menu);
  } catch (err) {
    console.error("Error fetching menu:", err.message);
    res.status(500).json({ error: "Failed to fetch menu!" });
  }
};
