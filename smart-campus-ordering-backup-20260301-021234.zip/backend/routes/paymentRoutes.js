const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const { initiatePayment, handleIPN, verifyPayment } = require('../controllers/paymentController');

// Initiate payment
router.post('/initiate', auth, initiatePayment);

// Verify payment status
router.get('/verify/:orderId', auth, verifyPayment);

// IPN handler (webhook from SSLCommerz - no auth required)
router.post('/ipn', handleIPN);

module.exports = router;
