const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const {
  addMenuItem,
  updateMenuItem,
  deleteMenuItem,
  getVendorMenu,
  getPublicVendorMenu   // <-- IMPORT the new function
} = require('../controllers/menuController');

// Public route: get menu items by vendor ID (no auth required)
router.get('/vendor/:vendorId', getPublicVendorMenu);

// Protected vendor routes
router.get('/vendor', auth, getVendorMenu);         // vendor's own menu
router.post('/', auth, addMenuItem);
router.put('/:id', auth, updateMenuItem);
router.delete('/:id', auth, deleteMenuItem);

module.exports = router;