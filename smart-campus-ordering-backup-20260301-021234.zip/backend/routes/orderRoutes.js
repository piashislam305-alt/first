// routes/orderRoutes.js

const express = require('express');
const router = express.Router();

const auth = require('../middlewares/auth');   // ✅ FIXED IMPORT

const { 
  createOrder, 
  updateOrderStatus, 
  getStudentOrders,
  getVendorOrders,
  cancelOrder
} = require('../controllers/orderController');

// Create new order (Student)
router.post('/', auth, createOrder);

// Get student orders
router.get('/student', auth, getStudentOrders);

// Get vendor orders
router.get('/vendor', auth, getVendorOrders);

// Update order status (Vendor)
router.put('/:id', auth, updateOrderStatus);

// Cancel order (Student)
router.put('/:id/cancel', auth, cancelOrder);

module.exports = router;