const express = require('express');
const router = express.Router();

const auth = require('../middlewares/auth');
const roleCheck = require('../middlewares/roleCheck');

const adminController = require('../controllers/adminController');

// Example route
router.get('/users', auth, roleCheck('admin'), adminController.getAllUsers);
router.put('/users/:id/status', auth, roleCheck('admin'), adminController.toggleUserStatus);
router.get('/analytics', auth, roleCheck('admin'), adminController.getSystemAnalytics);

module.exports = router;
