const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const {
  getProfile,
  updateProfile,
  getAllVendors,
  getVendorById,
  getDashboardAnalytics,
  getSchedule,
  updateSchedule,
  changePassword
} = require('../controllers/vendorController');

// Public vendor routes
router.get('/all', getAllVendors);

// Private vendor routes (require auth)
router.get('/profile', auth, getProfile);
router.put('/profile', auth, updateProfile);
router.get('/dashboard/analytics', auth, getDashboardAnalytics);
router.get('/schedule', auth, getSchedule);
router.put('/schedule', auth, updateSchedule);
router.put('/change-password', auth, changePassword);

// Keep dynamic public route last so it does not shadow static routes
router.get('/:id', getVendorById);

module.exports = router;
