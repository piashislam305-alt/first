const express = require('express');
const router = express.Router();

const auth = require('../middlewares/auth');
const roleCheck = require('../middlewares/roleCheck');

const analyticsController = require('../controllers/analyticsController');

// Vendor routes
router.get('/sales', auth, roleCheck('vendor'), analyticsController.getVendorSalesReport);

router.get('/popular-items', auth, roleCheck('vendor'), analyticsController.getPopularItems);

// Admin route
router.get('/system', auth, roleCheck('admin'), analyticsController.getSystemAnalytics);

module.exports = router;