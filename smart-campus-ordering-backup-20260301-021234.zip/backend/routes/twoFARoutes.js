const express = require('express');
const router = express.Router();

const auth = require('../middlewares/auth');
const roleCheck = require('../middlewares/roleCheck');
const twoFAController = require('../controllers/twoFAController');

// Generate 2FA secret
router.get('/generate', auth, roleCheck('admin'), twoFAController.generate2FASecret);

// Verify 2FA token
router.post('/verify', auth, roleCheck('admin'), twoFAController.verify2FAToken);

module.exports = router;
