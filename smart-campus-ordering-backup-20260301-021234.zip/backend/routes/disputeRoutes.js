const express = require('express');
const router = express.Router();

const auth = require('../middlewares/auth');
const roleCheck = require('../middlewares/roleCheck');

const disputeController = require('../controllers/disputeController');

// Student route - create dispute
router.post('/', auth, roleCheck('student'), disputeController.createDispute);

// Admin routes - get all disputes
router.get('/', auth, roleCheck('admin'), disputeController.getAllDisputes);

// Admin route - update dispute status
router.put('/:id', auth, roleCheck('admin'), disputeController.updateDisputeStatus);

module.exports = router;
