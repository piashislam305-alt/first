 
 
 
 const app = require('./app');
const http = require('http');
const socketIo = require('socket.io');
const logger = require('./utils/logger');

const PORT = process.env.PORT || 5000;

const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true
  },
  transports: ['websocket', 'polling'],
  pingInterval: 25000,
  pingTimeout: 60000
});

// Socket.IO Setup
io.on('connection', (socket) => {
  logger.info(`Client connected: ${socket.id}`);
  
  // Join vendor room
  socket.on('join-vendor', (vendorId) => {
    const normalizedId = String(vendorId || '').trim();
    if (!normalizedId) {
      return;
    }
    socket.join(`vendor-${normalizedId}`);
    logger.info(`Socket ${socket.id} joined vendor-${normalizedId}`);
  });
  
  // Join student room for order updates
  socket.on('join-student', (studentId) => {
    const normalizedId = String(studentId || '').trim();
    if (!normalizedId) {
      return;
    }
    socket.join(`student-${normalizedId}`);
    logger.info(`Socket ${socket.id} joined student-${normalizedId}`);
  });

  socket.on('error', (error) => {
    logger.error(`Socket error (${socket.id}): ${error.message}`);
  });
  
  socket.on('disconnect', () => {
    logger.info(`Client disconnected: ${socket.id}`);
  });
});

// Attach io to app
app.set('io', io);

// Start Server
server.listen(PORT, () => {
  logger.info(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
});
