const nodemailer = require('nodemailer');

// Create reusable transporter object using SMTP transport
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Send order notification
exports.sendOrderNotification = async (email, orderId, status) => {
  const statusMessages = {
    preparing: "is being prepared",
    ready: "is ready for pickup",
    completed: "has been completed",
    cancelled: "was cancelled"
  };

  try {
    await transporter.sendMail({
      from: `"Campus Eats" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: `Order Update: #${orderId.slice(-6)}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2d3748;">Order Status Update</h2>
          <p>Your order <strong>#${orderId.slice(-6)}</strong> ${statusMessages[status]}.</p>
          ${status === 'ready' ? 
            '<p>Please pick it up at the vendor location.</p>' : ''}
          <p>Thank you for using Campus Eats!</p>
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0;">
            <p>Campus Eats Team</p>
            <p>Chittagong University of Engineering & Technology</p>
          </div>
        </div>
      `
    });
  } catch (err) {
    console.error('Failed to send email notification:', err);
  }
};

// Send dispute notification
exports.sendDisputeNotification = async (email, orderId) => {
  try {
    await transporter.sendMail({
      from: `"Campus Eats" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: `New Dispute for Order #${orderId.slice(-6)}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #2d3748;">Dispute Submitted</h2>
          <p>A dispute has been submitted for your order <strong>#${orderId.slice(-6)}</strong>.</p>
          <p>Our team will review it shortly and contact you for resolution.</p>
          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0;">
            <p>Campus Eats Support Team</p>
          </div>
        </div>
      `
    });
  } catch (err) {
    console.error('Failed to send dispute notification:', err);
  }
};