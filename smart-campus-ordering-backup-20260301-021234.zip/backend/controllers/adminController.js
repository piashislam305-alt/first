const User = require('../models/User');
const Vendor = require('../models/Vendor');
const Order = require('../models/Order');
const Dispute = require('../models/Dispute');

// @desc    Get all users
// @route   GET /api/admin/users
exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json(users);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// @desc    Toggle user status
// @route   PUT /api/admin/users/:id/status
exports.toggleUserStatus = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    user.isActive = !user.isActive;
    await user.save();

    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// @desc    Get system analytics
// @route   GET /api/admin/analytics
exports.getSystemAnalytics = async (req, res) => {
  try {
    const [totalUsers, totalVendors, totalOrders, revenue] = await Promise.all([
      User.countDocuments(),
      Vendor.countDocuments(),
      Order.countDocuments(),
      Order.aggregate([{ $group: { _id: null, total: { $sum: "$total" } } }])
    ]);

    res.json({
      totalUsers,
      totalVendors,
      totalOrders,
      totalRevenue: revenue[0]?.total || 0
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};