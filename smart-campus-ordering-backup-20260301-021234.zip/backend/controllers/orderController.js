const Order = require('../models/Order');
const MenuItem = require('../models/MenuItem');
const Vendor = require('../models/Vendor');

const ORDER_STATUSES = ['pending', 'preparing', 'ready', 'shipped', 'completed', 'cancelled'];

const parsePositiveInteger = (value) => {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isInteger(parsed) || parsed <= 0) {
    return null;
  }
  return parsed;
};

const applyLimit = (query, limitParam) => {
  const limit = parsePositiveInteger(limitParam);
  return limit ? query.limit(limit) : query;
};

const emitToVendorRooms = (req, vendorId, vendorUserId, event, payload) => {
  const io = req.app.get('io');
  if (!io) {
    return;
  }

  io.to(`vendor-${vendorId}`).emit(event, payload);
  if (vendorUserId) {
    io.to(`vendor-${vendorUserId}`).emit(event, payload);
  }
};

const emitOrderUpdate = (req, order, status, vendorUserId) => {
  const io = req.app.get('io');
  if (!io) {
    return;
  }

  const payload = {
    orderId: order._id,
    status
  };

  emitToVendorRooms(req, order.vendorId.toString(), vendorUserId, 'orderUpdate', payload);
  io.to(`student-${order.studentId}`).emit('orderUpdate', payload);
};

// Create new order
const createOrder = async (req, res) => {
  const { items, vendorId, paymentStatus } = req.body;

  try {
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ msg: 'Invalid items array' });
    }

    if (!vendorId) {
      return res.status(400).json({ msg: 'Vendor ID is required' });
    }

    const vendor = await Vendor.findById(vendorId).select('_id userId').lean();
    if (!vendor) {
      return res.status(404).json({ msg: 'Vendor not found' });
    }

    let calculatedTotal = 0;
    const normalizedItems = [];

    for (const item of items) {
      const quantity = parsePositiveInteger(item.quantity);
      if (!item.menuItemId || !quantity) {
        return res.status(400).json({ msg: 'Each item requires menuItemId and a positive quantity' });
      }

      const menuItem = await MenuItem.findOne({
        _id: item.menuItemId,
        vendorId: vendor._id
      });

      if (!menuItem) {
        return res.status(404).json({
          msg: `Menu item ${item.menuItemId} not found for this vendor`
        });
      }

      if (!menuItem.isAvailable) {
        return res.status(400).json({
          msg: `Menu item ${menuItem.name} is currently unavailable`
        });
      }

      normalizedItems.push({
        menuItemId: menuItem._id,
        quantity
      });
      calculatedTotal += menuItem.price * quantity;
    }

    const normalizedPaymentStatus = paymentStatus === 'completed' ? 'completed' : 'pending';

    const order = new Order({
      studentId: req.user.id,
      vendorId: vendor._id,
      items: normalizedItems,
      total: calculatedTotal,
      status: 'pending',
      paymentStatus: normalizedPaymentStatus
    });

    await order.save();

    emitToVendorRooms(req, vendor._id.toString(), vendor.userId?.toString(), 'newOrder', {
      orderId: order._id,
      status: order.status
    });

    res.status(201).json(order);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Update order status
const updateOrderStatus = async (req, res) => {
  const { status } = req.body;

  try {
    if (!ORDER_STATUSES.includes(status)) {
      return res.status(400).json({ msg: 'Invalid order status' });
    }

    const vendor = await Vendor.findOne({ userId: req.user.id }).select('_id').lean();
    if (!vendor) {
      return res.status(403).json({ msg: 'Only vendors can update order status' });
    }

    const order = await Order.findOneAndUpdate(
      { _id: req.params.id, vendorId: vendor._id },
      { status },
      { new: true }
    );

    if (!order) {
      return res.status(404).json({ msg: 'Order not found for this vendor' });
    }

    emitOrderUpdate(req, order, status, req.user.id);

    res.json(order);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Get student orders
const getStudentOrders = async (req, res) => {
  try {
    const ordersQuery = Order.find({ studentId: req.user.id })
      .populate('vendorId', 'businessName')
      .populate('items.menuItemId', 'name price')
      .sort({ createdAt: -1 });
    const orders = await applyLimit(ordersQuery, req.query.limit);

    res.json(orders);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Get vendor orders
const getVendorOrders = async (req, res) => {
  try {
    const vendor = await Vendor.findOne({ userId: req.user.id });

    if (!vendor) {
      return res.status(404).json({ msg: 'Vendor not found' });
    }

    const ordersQuery = Order.find({ vendorId: vendor._id })
      .populate('studentId', 'email')
      .populate('items.menuItemId', 'name price')
      .sort({ createdAt: -1 });
    const orders = await applyLimit(ordersQuery, req.query.limit);

    res.json(orders);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// Cancel order
const cancelOrder = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);

    if (!order) {
      return res.status(404).json({ msg: 'Order not found' });
    }

    if (order.studentId.toString() !== req.user.id) {
      return res.status(403).json({ msg: 'Not authorized to cancel this order' });
    }

    if (!['pending', 'preparing'].includes(order.status)) {
      return res.status(400).json({ msg: `Cannot cancel order with status ${order.status}` });
    }

    order.status = 'cancelled';
    await order.save();

    const vendor = await Vendor.findById(order.vendorId).select('userId').lean();
    emitOrderUpdate(req, order, 'cancelled', vendor?.userId?.toString());

    res.json(order);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

module.exports = {
  createOrder,
  updateOrderStatus,
  getStudentOrders,
  getVendorOrders,
  cancelOrder
};
