const Dispute = require('../models/Dispute');
const Order = require('../models/Order');
const Student = require('../models/Student');
const { sendDisputeNotification } = require('../services/emailService');

// Create a new dispute
exports.createDispute = async (req, res) => {
  try {
    const { orderId, reason } = req.body;
    
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    if (order.studentId.toString() !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized to dispute this order' });
    }
    
    const dispute = new Dispute({
      orderId,
      studentId: req.user.id,
      vendorId: order.vendorId,
      reason,
      status: 'pending'
    });
    
    await dispute.save();
    
    // Notify admin
    sendDisputeNotification(process.env.ADMIN_EMAIL, orderId);
    
    res.status(201).json(dispute);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create dispute' });
  }
};

// Get all disputes
exports.getAllDisputes = async (req, res) => {
  try {
    const disputes = await Dispute.find()
      .populate('studentId', 'name')
      .populate('vendorId', 'businessName')
      .sort({ createdAt: -1 });
      
    res.json(disputes);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch disputes' });
  }
};

// Update dispute status
exports.updateDisputeStatus = async (req, res) => {
  try {
    const { status, resolution } = req.body;
    
    const dispute = await Dispute.findByIdAndUpdate(
      req.params.id,
      { status, resolution, resolvedAt: new Date() },
      { new: true }
    );
    
    if (!dispute) {
      return res.status(404).json({ error: 'Dispute not found' });
    }
    
    res.json(dispute);
  } catch (err) {
    res.status(500).json({ error: 'Failed to update dispute' });
  }
};