const Vendor = require('../models/Vendor');
const MenuItem = require('../models/MenuItem');
const Order = require('../models/Order');
const User = require('../models/User');
const bcrypt = require('bcryptjs'); // Ensure bcrypt is installed

// @desc    Get vendor profile
// @route   GET /api/vendor/profile
exports.getProfile = async (req, res) => {
  try {
    const vendor = await Vendor.findOne({ userId: req.user.id })
      .populate('userId', 'email isActive')
      .lean();

    if (!vendor) {
      return res.status(404).json({ msg: 'Vendor profile not found' });
    }

    res.json(vendor);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Update vendor profile
// @route   PUT /api/vendor/profile
exports.updateProfile = async (req, res) => {
  try {
    const { businessName, description, contactNumber, logo } = req.body;

    // Build update object dynamically, only including provided fields
    const updates = {};
    if (businessName) updates.businessName = businessName;
    if (description) updates.description = description;
    if (contactNumber) updates.contactNumber = contactNumber;
    if (logo) updates.logo = logo;

    // Ensure at least one field is provided
    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ msg: 'No update fields provided' });
    }

    const vendor = await Vendor.findOneAndUpdate(
      { userId: req.user.id },
      updates,
      { new: true, runValidators: true } // Run schema validators
    );

    if (!vendor) {
      return res.status(404).json({ msg: 'Vendor profile not found' });
    }

    res.json(vendor);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Get all active vendors (for students)
// @route   GET /api/vendor/all
exports.getAllVendors = async (req, res) => {
  try {
    const vendors = await Vendor.find({ isActive: true })
      .select('_id businessName description logo contactNumber schedule isActive')
      .lean();

    res.json(vendors);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Get single vendor by ID (public)
// @route   GET /api/vendor/:id
exports.getVendorById = async (req, res) => {
  try {
    const vendor = await Vendor.findById(req.params.id).lean();

    if (!vendor) {
      return res.status(404).json({ msg: 'Vendor not found' });
    }

    res.json(vendor);
  } catch (err) {
    console.error(err.message);
    // Handle invalid ObjectId
    if (err.kind === 'ObjectId') {
      return res.status(400).json({ msg: 'Invalid vendor ID' });
    }
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Get vendor dashboard analytics
// @route   GET /api/vendor/dashboard/analytics
exports.getDashboardAnalytics = async (req, res) => {
  try {
    const vendor = await Vendor.findOne({ userId: req.user.id }).lean();

    if (!vendor) {
      return res.status(404).json({ msg: 'Vendor not found' });
    }

    // Total orders count
    const totalOrders = await Order.countDocuments({ vendorId: vendor._id });

    // Total revenue from completed orders using aggregation (more efficient)
    const revenueResult = await Order.aggregate([
      { $match: { vendorId: vendor._id, status: 'completed', paymentStatus: 'completed' } },
      { $group: { _id: null, total: { $sum: '$total' } } }
    ]);
    const totalRevenue = revenueResult.length > 0 ? revenueResult[0].total : 0;

    // Menu items count
    const menuItemsCount = await MenuItem.countDocuments({ vendorId: vendor._id });

    // Popular items (top 5 by quantity) with item details
    const popularItems = await Order.aggregate([
      { $match: { vendorId: vendor._id } },
      { $unwind: '$items' },
      { $group: {
          _id: '$items.menuItemId',
          totalQuantity: { $sum: '$items.quantity' }
      }},
      { $sort: { totalQuantity: -1 } },
      { $limit: 5 },
      { $lookup: {
          from: 'menuitems', // Name of the MenuItem collection in MongoDB
          localField: '_id',
          foreignField: '_id',
          as: 'itemDetails'
      }},
      { $unwind: '$itemDetails' },
      { $project: {
          menuItemId: '$_id',
          name: '$itemDetails.name',
          price: '$itemDetails.price',
          totalQuantity: 1,
          _id: 0
      }}
    ]);

    res.json({
      totalOrders,
      totalRevenue,
      menuItemsCount,
      popularItems
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Get vendor schedule and open status
// @route   GET /api/vendor/schedule
exports.getSchedule = async (req, res) => {
  try {
    const vendor = await Vendor.findOne({ userId: req.user.id })
      .select('schedule isActive')
      .lean();

    if (!vendor) {
      return res.status(404).json({ msg: 'Vendor not found' });
    }

    res.json({
      schedule: vendor.schedule || {},
      isOpen: vendor.isActive || false
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Update vendor schedule and open status
// @route   PUT /api/vendor/schedule
exports.updateSchedule = async (req, res) => {
  try {
    const { schedule, isOpen } = req.body;

    // Build update object
    const updates = {};
    if (schedule && typeof schedule === 'object') updates.schedule = schedule;
    if (isOpen !== undefined) {
      if (typeof isOpen !== 'boolean') {
        return res.status(400).json({ msg: 'isOpen must be a boolean' });
      }
      updates.isActive = isOpen;
    }

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ msg: 'No valid fields to update' });
    }

    const vendor = await Vendor.findOneAndUpdate(
      { userId: req.user.id },
      updates,
      { new: true, runValidators: true }
    );

    if (!vendor) {
      return res.status(404).json({ msg: 'Vendor not found' });
    }

    res.json({ msg: 'Schedule updated successfully', vendor });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Change vendor account password
// @route   PUT /api/vendor/change-password
exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ msg: 'Current and new password are required' });
    }

    // Optional: Add password strength validation
    if (newPassword.length < 6) {
      return res.status(400).json({ msg: 'New password must be at least 6 characters' });
    }

    const user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    // Verify current password
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Current password is incorrect' });
    }

    // Hash new password manually (assuming pre-save hook may also hash, but explicit is safer)
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(newPassword, salt);
    await user.save();

    res.json({ msg: 'Password updated successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};