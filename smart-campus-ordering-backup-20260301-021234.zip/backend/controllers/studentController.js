const Student = require('../models/Student');
const User = require('../models/User');

// @desc    Get student profile
// @route   GET /api/student/profile
exports.getProfile = async (req, res) => {
  try {
    const student = await Student.findOne({ userId: req.user.id }).populate('userId', 'email isActive');
    
    if (!student) {
      return res.status(404).json({ msg: 'Student profile not found' });
    }
    
    res.json(student);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Update student profile
// @route   PUT /api/student/profile
exports.updateProfile = async (req, res) => {
  try {
    const { name, phone, department, batch, studentId } = req.body;
    
    const updates = {};
    if (name) updates.name = name;
    if (phone) updates.phone = phone;
    if (department) updates.department = department;
    if (batch) updates.batch = batch;
    if (studentId) updates.studentId = studentId;
    
    const student = await Student.findOneAndUpdate(
      { userId: req.user.id },
      updates,
      { new: true }
    );
    
    if (!student) {
      return res.status(404).json({ msg: 'Student profile not found' });
    }
    
    res.json(student);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Change password
// @route   PUT /api/student/change-password
exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ msg: 'Current and new password are required' });
    }
    
    const user = await User.findById(req.user.id);
    
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Current password is incorrect' });
    }
    
    user.password = newPassword;
    await user.save();
    
    res.json({ msg: 'Password updated successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};
