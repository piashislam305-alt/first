const User = require('../models/User');
const Student = require('../models/Student');
const Vendor = require('../models/Vendor');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// @desc    Register a new user
// @route   POST /api/auth/register
exports.register = async (req, res) => {
  const { email, password, role, name, phone, department, batch, studentId, businessName, description, contactNumber, logo } = req.body;

  try {
    if (!['student', 'vendor'].includes(role)) {
      return res.status(403).json({ msg: 'Public registration is allowed only for student and vendor roles' });
    }

    // Check if user exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ msg: 'User already exists' });
    }

    // Validate CUET email for students
    if (role === 'student' && !email.endsWith('@student.cuet.ac.bd')) {
      return res.status(400).json({ msg: 'Invalid CUET email format' });
    }

    // Create user
    user = new User({ email, password, role });
    await user.save();

    // Create role-specific profile
    if (role === 'student') {
      if (!name || !phone || !department || !batch || !studentId) {
        return res.status(400).json({ msg: 'Missing required student fields' });
      }
      await Student.create({
        userId: user._id,
        name,
        phone,
        department,
        batch,
        studentId
      });
    } else if (role === 'vendor') {
      if (!businessName || !description || !contactNumber) {
        return res.status(400).json({ msg: 'Missing required vendor fields' });
      }
      await Vendor.create({
        userId: user._id,
        businessName,
        description,
        contactNumber,
        logo: logo || ''
      });
    }

    // Generate JWT
    const payload = {
      user: {
        id: user.id,
        role: user.role,
        email: user.email
      }
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: '1d' },
      (err, token) => {
        if (err) throw err;
        res.json({ 
          token, 
          user: {
            id: user._id,
            email: user.email,
            role: user.role
          }
        });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error', error: err.message });
  }
};

// @desc    Authenticate user & get token
// @route   POST /api/auth/login
exports.login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(400).json({ msg: 'Invalid Credentials' });
    }

    const isMatch = await user.comparePassword(password);

    if (!isMatch) {
      return res.status(400).json({ msg: 'Invalid Credentials' });
    }

    if (!user.isActive) {
      return res.status(403).json({ msg: 'Your account is inactive. Please contact support.' });
    }

    const payload = {
      user: {
        id: user.id,
        role: user.role,
        email: user.email
      }
    };

    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: '1d' },
      (err, token) => {
        if (err) throw err;
        res.json({ 
          token, 
          user: {
            id: user._id,
            email: user.email,
            role: user.role
          }
        });
      }
    );
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error', error: err.message });
  }
};

// @desc    Get current user
// @route   GET /api/auth/user
exports.getUser = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    if (!user.isActive) {
      return res.status(403).json({ msg: 'Account inactive' });
    }

    let profile = null;
    if (user.role === 'student') {
      profile = await Student.findOne({ userId: user._id });
    } else if (user.role === 'vendor') {
      profile = await Vendor.findOne({ userId: user._id });
    }

    res.json({
      id: user._id,
      email: user.email,
      role: user.role,
      isActive: user.isActive,
      profile
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};
