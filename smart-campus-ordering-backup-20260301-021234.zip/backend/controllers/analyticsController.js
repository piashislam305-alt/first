const Order = require('../models/Order');
const Vendor = require('../models/Vendor');
const Student = require('../models/Student');

// Get sales report for vendor
exports.getVendorSalesReport = async (req, res) => {
  try {
    const { period = 'week' } = req.query;
    
    // Calculate date range
    const now = new Date();
    let startDate;
    
    switch (period) {
      case 'day':
        startDate = new Date(now.setDate(now.getDate() - 1));
        break;
      case 'week':
        startDate = new Date(now.setDate(now.getDate() - 7));
        break;
      case 'month':
        startDate = new Date(now.setMonth(now.getMonth() - 1));
        break;
      case 'year':
        startDate = new Date(now.setFullYear(now.getFullYear() - 1));
        break;
      default:
        startDate = new Date(now.setDate(now.getDate() - 7));
    }
    
    const orders = await Order.aggregate([
      {
        $match: {
          vendorId: req.user.id,
          status: 'completed',
          createdAt: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: null,
          totalOrders: { $sum: 1 },
          totalRevenue: { $sum: '$total' },
          avgOrderValue: { $avg: '$total' }
        }
      }
    ]);
    
    const result = orders[0] || {
      totalOrders: 0,
      totalRevenue: 0,
      avgOrderValue: 0
    };
    
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate sales report' });
  }
};

// Get popular items for vendor
exports.getPopularItems = async (req, res) => {
  try {
    const popularItems = await Order.aggregate([
      { $match: { vendorId: req.user.id, status: 'completed' } },
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.menuItemId',
          totalQuantity: { $sum: '$items.quantity' },
          totalRevenue: { $sum: { $multiply: ['$items.quantity', '$items.price'] } }
        }
      },
      { $sort: { totalQuantity: -1 } },
      { $limit: 5 },
      {
        $lookup: {
          from: 'menuitems',
          localField: '_id',
          foreignField: '_id',
          as: 'menuItem'
        }
      },
      { $unwind: '$menuItem' },
      {
        $project: {
          name: '$menuItem.name',
          totalQuantity: 1,
          totalRevenue: 1
        }
      }
    ]);
    
    res.json(popularItems);
  } catch (err) {
    res.status(500).json({ error: 'Failed to get popular items' });
  }
};

// Get system-wide analytics (admin only)
exports.getSystemAnalytics = async (req, res) => {
  try {
    const [totalStudents, totalVendors, totalOrders, totalRevenue] = await Promise.all([
      Student.countDocuments(),
      Vendor.countDocuments(),
      Order.countDocuments(),
      Order.aggregate([
        { $match: { status: 'completed' } },
        { $group: { _id: null, total: { $sum: '$total' } } }
      ])
    ]);
    
    res.json({
      totalStudents,
      totalVendors,
      totalOrders,
      totalRevenue: totalRevenue[0]?.total || 0
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to get system analytics' });
  }
};