const speakeasy = require('speakeasy');
const qrcode = require('qrcode');
const Admin = require('../models/Admin');

// Generate 2FA secret
exports.generate2FASecret = async (req, res) => {
  try {
    const secret = speakeasy.generateSecret({ 
      name: `CampusEats (${req.user.email})` 
    });
    
    // Save secret to admin account
    await Admin.findOneAndUpdate(
      { userId: req.user.id },
      { twoFASecret: secret.base32 }
    );
    
    // Generate QR code URL
    qrcode.toDataURL(secret.otpauth_url, (err, dataUrl) => {
      if (err) {
        return res.status(500).json({ error: 'Failed to generate QR code' });
      }
      
      res.json({
        secret: secret.base32,
        qrCode: dataUrl
      });
    });
  } catch (err) {
    res.status(500).json({ error: '2FA setup failed' });
  }
};

// Verify 2FA token
exports.verify2FAToken = async (req, res) => {
  try {
    const { token } = req.body;
    const admin = await Admin.findOne({ userId: req.user.id });
    
    if (!admin || !admin.twoFASecret) {
      return res.status(400).json({ error: '2FA not set up' });
    }
    
    const verified = speakeasy.totp.verify({
      secret: admin.twoFASecret,
      encoding: 'base32',
      token
    });
    
    if (verified) {
      // Enable 2FA for the admin
      await Admin.findOneAndUpdate(
        { userId: req.user.id },
        { twoFAEnabled: true }
      );
      
      res.json({ verified: true });
    } else {
      res.status(400).json({ verified: false, error: 'Invalid token' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Verification failed' });
  }
};

// Middleware to require 2FA
exports.require2FA = async (req, res, next) => {
  try {
    const admin = await Admin.findOne({ userId: req.user.id });
    
    if (!admin) {
      return res.status(403).json({ error: 'Admin account not found' });
    }
    
    if (admin.twoFAEnabled) {
      const token = req.headers['x-2fa-token'];
      
      if (!token) {
        return res.status(401).json({ error: '2FA token required' });
      }
      
      const verified = speakeasy.totp.verify({
        secret: admin.twoFASecret,
        encoding: 'base32',
        token
      });
      
      if (!verified) {
        return res.status(401).json({ error: 'Invalid 2FA token' });
      }
    }
    
    next();
  } catch (err) {
    res.status(500).json({ error: '2FA check failed' });
  }
};