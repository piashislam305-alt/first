const Order = require('../models/Order');
const Payment = require('../models/Payment');
const User = require('../models/User');
const axios = require('axios');

// @desc    Initiate payment
// @route   POST /api/payment/initiate
exports.initiatePayment = async (req, res) => {
  const { orderId, amount } = req.body;
  
  try {
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ msg: 'Order not found' });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    // SSLCommerz payload
    const payload = {
      store_id: process.env.SSLCOMMERZ_STORE_ID,
      store_passwd: process.env.SSLCOMMERZ_STORE_PASS,
      total_amount: amount,
      currency: 'BDT',
      tran_id: orderId,
      success_url: `${process.env.FRONTEND_URL}/payment/success`,
      fail_url: `${process.env.FRONTEND_URL}/payment/fail`,
      cancel_url: `${process.env.FRONTEND_URL}/payment/cancel`,
      ipn_url: `${process.env.BACKEND_URL}/api/payment/ipn`,
      shipping_method: 'NO',
      product_name: 'Food Order',
      product_category: 'Food',
      product_profile: 'general',
      cus_name: user.email.split('@')[0],
      cus_email: user.email,
      cus_add1: 'CUET Campus',
      cus_city: 'Chittagong',
      cus_country: 'Bangladesh',
    };

    const response = await axios.post(
      'https://sandbox.sslcommerz.com/gwprocess/v4/api.php',
      payload
    );

    if (!response.data.success) {
      return res.status(400).json({ msg: 'Failed to initiate payment' });
    }

    // Create payment record
    const payment = new Payment({
      orderId,
      amount,
      transactionId: response.data.sessionkey,
      status: 'pending'
    });
    await payment.save();

    res.json({ paymentUrl: response.data.GatewayPageURL });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Handle IPN (Instant Payment Notification)
// @route   POST /api/payment/ipn
exports.handleIPN = async (req, res) => {
  const { tran_id, status } = req.body;
  
  try {
    // Update payment status
    await Payment.findOneAndUpdate(
      { transactionId: tran_id },
      { status: status === 'VALID' ? 'completed' : 'failed' }
    );

    // Update order status
    if (status === 'VALID') {
      await Order.findByIdAndUpdate(tran_id, { paymentStatus: 'completed' });
    } else {
      await Order.findByIdAndUpdate(tran_id, { paymentStatus: 'failed' });
    }

    res.sendStatus(200);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};

// @desc    Verify payment status
// @route   GET /api/payment/verify/:orderId
exports.verifyPayment = async (req, res) => {
  try {
    const payment = await Payment.findOne({ orderId: req.params.orderId });
    
    if (!payment) {
      return res.status(404).json({ msg: 'Payment not found' });
    }

    res.json({ status: payment.status });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: 'Server error' });
  }
};