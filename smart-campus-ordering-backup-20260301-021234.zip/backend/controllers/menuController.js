const MenuItem = require("../models/MenuItem");
const Vendor = require("../models/Vendor");

// Add new menu item
const addMenuItem = async (req, res) => {
  try {
    const { name, price, category, description, image, isAvailable } = req.body;
    
    if (!name || price === undefined || price === null) {
      return res.status(400).json({ error: "Name and price are required" });
    }

    const parsedPrice = Number.parseFloat(price);
    if (Number.isNaN(parsedPrice) || parsedPrice < 0) {
      return res.status(400).json({ error: "Price must be a non-negative number" });
    }
    
    // Get vendor by userId
    const vendor = await Vendor.findOne({ userId: req.user.id });
    if (!vendor) {
      return res.status(404).json({ error: "Vendor profile not found" });
    }
    
    const newItem = new MenuItem({
      vendorId: vendor._id,
      name,
      price: parsedPrice,
      category: category || "Uncategorized",
      description: description || "",
      image: image || "",
      isAvailable: isAvailable ?? true
    });
    
    await newItem.save();
    res.status(201).json(newItem);
  } catch (err) {
    console.error("Error adding item:", err.message);
    res.status(500).json({ error: "Failed to add item!" });
  }
};

// Update menu item
const updateMenuItem = async (req, res) => {
  try {
    // Get vendor by userId
    const vendor = await Vendor.findOne({ userId: req.user.id });
    if (!vendor) {
      return res.status(404).json({ error: "Vendor profile not found" });
    }
    
    const updatedItem = await MenuItem.findOneAndUpdate(
      { _id: req.params.id, vendorId: vendor._id },
      req.body,
      { new: true }
    );
    
    if (!updatedItem) {
      return res.status(404).json({ error: "Item not found!" });
    }
    
    res.json(updatedItem);
  } catch (err) {
    console.error("Error updating item:", err.message);
    res.status(500).json({ error: "Update failed!" });
  }
};

// Delete menu item
const deleteMenuItem = async (req, res) => {
  try {
    // Get vendor by userId
    const vendor = await Vendor.findOne({ userId: req.user.id });
    if (!vendor) {
      return res.status(404).json({ error: "Vendor profile not found" });
    }
    
    const deletedItem = await MenuItem.findOneAndDelete({
      _id: req.params.id,
      vendorId: vendor._id
    });
    
    if (!deletedItem) {
      return res.status(404).json({ error: "Item not found!" });
    }
    
    res.json({ message: "Item deleted!" });
  } catch (err) {
    console.error("Error deleting item:", err.message);
    res.status(500).json({ error: "Deletion failed!" });
  }
};

// Get vendor's own menu (authenticated)
const getVendorMenu = async (req, res) => {
  try {
    // Get vendor by userId
    const vendor = await Vendor.findOne({ userId: req.user.id });
    if (!vendor) {
      return res.status(404).json({ error: "Vendor profile not found" });
    }
    
    const menu = await MenuItem.find({ vendorId: vendor._id });
    res.json(menu);
  } catch (err) {
    console.error("Error fetching menu:", err.message);
    res.status(500).json({ error: "Failed to fetch menu!" });
  }
};

// Get public menu by vendor ID (no auth required)
const getPublicVendorMenu = async (req, res) => {
  try {
    const { vendorId } = req.params;
    // Return only available items for students
    const menu = await MenuItem.find({ vendorId, isAvailable: true });
    res.json(menu);
  } catch (err) {
    console.error('Error fetching public menu:', err.message);
    res.status(500).json({ error: 'Failed to fetch menu' });
  }
};

// Export all functions
module.exports = {
  addMenuItem,
  updateMenuItem,
  deleteMenuItem,
  getVendorMenu,
  getPublicVendorMenu
};
