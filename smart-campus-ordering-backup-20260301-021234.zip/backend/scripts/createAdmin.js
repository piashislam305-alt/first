const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/User');
const Admin = require('../models/Admin');

dotenv.config();

const [,, email, password] = process.argv;

if (!email || !password) {
  console.error('Usage: node scripts/createAdmin.js <email> <password>');
  process.exit(1);
}

const run = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });

    let user = await User.findOne({ email });
    if (!user) {
      user = new User({
        email,
        password,
        role: 'admin',
        isActive: true
      });
      await user.save();
      console.log(`Created user ${email} with admin role.`);
    } else {
      user.role = 'admin';
      user.password = password;
      user.isActive = true;
      await user.save();
      console.log(`Updated existing user ${email} to admin role.`);
    }

    const existingAdmin = await Admin.findOne({ userId: user._id });
    if (!existingAdmin) {
      await Admin.create({ userId: user._id });
      console.log('Created admin profile.');
    } else {
      console.log('Admin profile already exists.');
    }
  } catch (error) {
    console.error('Failed to create admin:', error.message);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
};

run();
