const mongoose = require('mongoose');

// Validate CUET email
exports.isValidCuetEmail = (email) => {
  const regex = /^[a-zA-Z0-9._-]+@student\.cuet\.ac\.bd$/;
  return regex.test(email);
};

// Validate MongoDB ID
exports.isValidId = (id) => {
  return mongoose.Types.ObjectId.isValid(id);
};

// Validate order status
exports.isValidOrderStatus = (status) => {
  const validStatuses = [
    'pending', 'preparing', 'ready', 'shipped', 'completed', 'cancelled'
  ];
  return validStatuses.includes(status);
};

// Validate payment status
exports.isValidPaymentStatus = (status) => {
  const validStatuses = ['pending', 'completed', 'failed'];
  return validStatuses.includes(status);
};