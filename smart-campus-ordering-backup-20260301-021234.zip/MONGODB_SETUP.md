# MongoDB Setup Guide for Windows

## Option 1: MongoDB Community Edition (Local Installation)

### Step 1: Download MongoDB Community Edition
1. Visit: https://www.mongodb.com/try/download/community
2. Select:
   - Version: Latest (7.0 or newer)
   - OS: Windows (x64)
   - Package: MSI
3. Click **Download**

### Step 2: Install MongoDB
1. Run the downloaded `.msi` installer
2. Choose **Complete** installation
3. **IMPORTANT**: When prompted for "Install MongoDB Server as a Service"
   - ✅ Leave it checked (this auto-starts MongoDB)
   - Set "Service Name" to: `MongoDB`
4. Continue with default settings and finish installation

### Step 3: Verify MongoDB Installation
Open PowerShell and run:
```powershell
mongod --version
```

You should see the version number.

### Step 4: Start MongoDB Service
MongoDB should start automatically if installed as a service. Verify with:
```powershell
# Check if MongoDB service is running
Get-Service MongoDB

# Or manually start it
Start-Service MongoDB
```

### Step 5: Test MongoDB Connection
Open a new PowerShell and run:
```powershell
mongosh
```

You should see:
```
Current Mongosh Log ID: ...
Connecting to: mongodb://localhost:27017
test> 
```

If you see this, MongoDB is running! Type `exit` to quit.

---

## Option 2: MongoDB Atlas (Cloud Database - Alternative)

If you prefer cloud MongoDB instead of local:

### Step 1: Create MongoDB Atlas Account
1. Go to: https://www.mongodb.com/cloud/atlas
2. Click "Try Free"
3. Sign up with your email

### Step 2: Create Cluster
1. Create a new project
2. Click "Build a Cluster"
3. Choose **Free Tier**
4. Select region closest to you
5. Click **Create Deployment**

### Step 3: Get Connection String
1. Go to **Database** > **Connect**
2. Click **Drivers**
3. Copy the connection string
4. Replace `<password>` with your database password

### Step 4: Update .env
Replace:
```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/smartcampus
```

---

## Create Database & Collections (First Time Only)

After MongoDB is running, create the database:

### Using Mongosh CLI:
```powershell
mongosh

# Switch to database
use smartcampus

# Create collections (optional - MongoDB creates them automatically when you insert data)
db.createCollection("users")
db.createCollection("vendors")
db.createCollection("menuitems")
db.createCollection("orders")
db.createCollection("payments")
db.createCollection("students")

# Verify collections
show collections

# Exit
exit
```

---

## Troubleshooting

### MongoDB won't connect
```powershell
# Check if service is running
Get-Service MongoDB

# Restart service
Restart-Service MongoDB
```

### Port 27017 already in use
MongoDB uses port 27017 by default. If it's occupied:
```powershell
# Find process using port 27017
Get-NetTCPConnection -LocalPort 27017

# MongoDB server connection string in .env can specify different port:
# MONGODB_URI=mongodb://localhost:27018/smartcampus
```

### Can't find mongosh
Make sure MongoDB installation includes mongosh. If not:
```powershell
npm install -g mongosh
```

---

## Now Start Your Backend

Once MongoDB is running:

```powershell
cd backend
npm run dev
```

You should see:
```
2026-02-28 22:26:16 [info]: MongoDB Connected
2026-02-28 22:26:16 [info]: Server running in development mode on port 5000
```

---

## Database Structure

Your app will create these collections automatically:

```
smartcampus/
├── users              (Students, Vendors, Admins)
├── students           (Student profiles)
├── vendors            (Vendor profiles)
├── menuitems          (Menu items)
├── orders             (Orders)
├── payments           (Payment records)
├── ratings            (Ratings/Reviews)
├── disputes           (Disputes)
├── auditlogs          (Admin audit logs)
└── admins             (Admin accounts)
```

---

## Useful MongoDB Commands

```powershell
mongosh

# Show all databases
show dbs

# Switch to database
use smartcampus

# Show all collections
show collections

# Count documents
db.users.countDocuments()

# View sample document
db.users.findOne()

# Find all vendors
db.vendors.find()

# Drop database (WARNING: Deletes everything)
db.dropDatabase()

# Exit
exit
```

---

**Status**: ✅ All configured for local MongoDB development

**Next**: Run `npm run dev` in the backend folder
