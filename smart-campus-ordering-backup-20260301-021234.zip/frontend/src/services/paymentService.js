/**
 * Mock Payment Service
 * Simulates payment processing without hitting real payment gateway
 */

// Card validation utilities
export const validateCardNumber = (cardNumber) => {
  const cleaned = cardNumber.replace(/\s+/g, '');
  
  // Luhn algorithm validation
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }

  let sum = 0;
  let isEven = false;

  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
};

export const validateCVV = (cvv) => {
  return /^\d{3,4}$/.test(cvv);
};

export const validateExpiryDate = (month, year) => {
  const today = new Date();
  const currentYear = today.getFullYear();
  const currentMonth = today.getMonth() + 1;

  const expYear = parseInt(year, 10);
  const expMonth = parseInt(month, 10);

  if (expYear < currentYear) {
    return false;
  }

  if (expYear === currentYear && expMonth < currentMonth) {
    return false;
  }

  return true;
};

export const detectCardType = (cardNumber) => {
  const cleaned = cardNumber.replace(/\s+/g, '');

  // Visa
  if (/^4[0-9]{12}(?:[0-9]{3})?$/.test(cleaned)) {
    return 'visa';
  }

  // Mastercard
  if (/^5[1-5][0-9]{14}$/.test(cleaned)) {
    return 'mastercard';
  }

  // American Express
  if (/^3[47][0-9]{13}$/.test(cleaned)) {
    return 'amex';
  }

  // Discover
  if (/^6(?:011|5[0-9]{2})[0-9]{12}$/.test(cleaned)) {
    return 'discover';
  }

  return 'unknown';
};

// Mock payment processing
export const processPayment = async ({
  cardNumber,
  cardholderName,
  expiryMonth,
  expiryYear,
  cvv,
  amount,
  description
}) => {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 2000));

  // Validation
  if (!validateCardNumber(cardNumber)) {
    throw new Error('Invalid card number');
  }

  if (!validateCVV(cvv)) {
    throw new Error('Invalid CVV');
  }

  if (!validateExpiryDate(expiryMonth, expiryYear)) {
    throw new Error('Card has expired');
  }

  // Mock processing logic
  // In a real application, this would call your backend API
  const cardType = detectCardType(cardNumber);
  const last4 = cardNumber.slice(-4);

  // Simulate occasional failures for testing
  const random = Math.random();
  if (random < 0.05) {
    // 5% chance of failure
    throw new Error('Payment declined by issuer. Please try again.');
  }

  // Success
  return {
    success: true,
    transactionId: `TXN_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    amount,
    cardType,
    last4,
    cardholderName,
    timestamp: new Date().toISOString(),
    description,
    status: 'completed'
  };
};

// Refund mock
export const refundPayment = async (transactionId, amount) => {
  await new Promise((resolve) => setTimeout(resolve, 1500));

  return {
    success: true,
    refundId: `REF_${Date.now()}`,
    originalTransactionId: transactionId,
    amount,
    timestamp: new Date().toISOString(),
    status: 'completed'
  };
};

// Get transaction history (mock)
export const getTransactionHistory = async (userId) => {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500));

  return [
    {
      id: 'TXN_1234567890_abc123',
      amount: 450,
      cardType: 'visa',
      last4: '4242',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      status: 'completed',
      description: 'Order #ORD_001'
    },
    {
      id: 'TXN_1234567891_def456',
      amount: 320,
      cardType: 'mastercard',
      last4: '5555',
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      status: 'completed',
      description: 'Order #ORD_002'
    }
  ];
};
