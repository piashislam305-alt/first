import io from 'socket.io-client';

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000';

let socket = null;
const roomState = {
  vendor: new Set(),
  student: new Set()
};

const emitJoin = (roomType, roomId) => {
  if (!socket || !socket.connected || !roomId) {
    return;
  }
  socket.emit(`join-${roomType}`, roomId);
};

const rejoinAllRooms = () => {
  roomState.vendor.forEach((id) => emitJoin('vendor', id));
  roomState.student.forEach((id) => emitJoin('student', id));
};

export const initializeSocket = () => {
  if (!socket) {
    socket = io(SOCKET_URL, {
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: 5,
      transports: ['websocket', 'polling'],
      withCredentials: true,
      autoConnect: true
    });

    socket.on('connect', () => {
      console.log('Socket connected:', socket.id);
      rejoinAllRooms();
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected');
    });

    socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
    });
  }
  return socket;
};

export const getSocket = () => {
  if (!socket) {
    initializeSocket();
  }
  return socket;
};

export const joinVendorRoom = (vendorId) => {
  if (!vendorId) {
    return;
  }
  const normalizedId = String(vendorId);
  roomState.vendor.add(normalizedId);
  const currentSocket = getSocket();
  if (currentSocket.connected) {
    currentSocket.emit('join-vendor', normalizedId);
  }
};

export const joinStudentRoom = (studentId) => {
  if (!studentId) {
    return;
  }
  const normalizedId = String(studentId);
  roomState.student.add(normalizedId);
  const currentSocket = getSocket();
  if (currentSocket.connected) {
    currentSocket.emit('join-student', normalizedId);
  }
};

export const onOrderUpdate = (callback) => {
  const socket = getSocket();
  socket.on('orderUpdate', callback);
};

export const onNewOrder = (callback) => {
  const socket = getSocket();
  socket.on('newOrder', callback);
};

export const emitOrderUpdate = (data) => {
  // Order status updates must be server-authoritative via API calls.
  // This helper remains for backward compatibility and no-ops intentionally.
  void data;
};

export const disconnectSocket = () => {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
  roomState.vendor.clear();
  roomState.student.clear();
};
