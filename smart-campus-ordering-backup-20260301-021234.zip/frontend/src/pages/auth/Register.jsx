import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { isValidCuetEmail, isPasswordStrong } from '../../utils/auth';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import './Register.css';

const Register = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    role: 'student',
    name: '',
    phone: '',
    department: '',
    batch: '',
    studentId: '',
    businessName: '',
    description: '',
    contactNumber: ''
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    // Clear error when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (formData.role === 'student' && !isValidCuetEmail(formData.email)) {
      newErrors.email = 'Please use a valid CUET student email';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (!isPasswordStrong(formData.password)) {
      newErrors.password = 'Password must be at least 8 characters with uppercase, lowercase, and number';
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    if (formData.role === 'student') {
      if (!formData.name) newErrors.name = 'Name is required';
      if (!formData.phone) newErrors.phone = 'Phone is required';
      if (!formData.department) newErrors.department = 'Department is required';
      if (!formData.batch) newErrors.batch = 'Batch is required';
      if (!formData.studentId) newErrors.studentId = 'Student ID is required';
    } else if (formData.role === 'vendor') {
      if (!formData.businessName) newErrors.businessName = 'Business name is required';
      if (!formData.description) newErrors.description = 'Business description is required';
      if (!formData.contactNumber) newErrors.contactNumber = 'Contact number is required';
    }

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    try {
      setLoading(true);
      setError('');

      const { confirmPassword, ...registrationData } = formData;

      const success = await register(
        formData.email,
        formData.password,
        formData.role,
        formData.role === 'student'
          ? { 
              name: formData.name, 
              phone: formData.phone,
              department: formData.department,
              batch: formData.batch,
              studentId: formData.studentId
            }
          : { 
              businessName: formData.businessName,
              description: formData.description,
              contactNumber: formData.contactNumber
            }
      );

      if (success) {
        navigate(formData.role === 'student' ? '/student' : '/vendor');
      }
    } catch (err) {
      setError('Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-blue-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <span className="text-4xl">🍽️</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Join Smart Campus</h1>
          <p className="text-gray-600 text-sm mt-2">
            Create your account to start ordering or selling
          </p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-xl shadow-lg p-8 space-y-6">
          {/* Error Alert */}
          {error && (
            <div className="p-4 bg-accent-50 border border-accent-200 rounded-lg">
              <p className="text-sm text-accent-800">{error}</p>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Role Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Register As
              </label>
              <div className="grid grid-cols-2 gap-4">
                {['student', 'vendor'].map((roleOption) => (
                  <label
                    key={roleOption}
                    className={`relative flex items-center p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      formData.role === roleOption
                        ? 'border-primary-600 bg-primary-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="role"
                      value={roleOption}
                      checked={formData.role === roleOption}
                      onChange={handleChange}
                      className="w-4 h-4 text-primary-600 cursor-pointer"
                    />
                    <span className="ml-3 font-medium text-gray-900 capitalize">
                      {roleOption === 'student' ? '👨‍🎓 Student' : '🏪 Vendor'}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Email Input */}
            <Input
              label="Email Address"
              type="email"
              name="email"
              placeholder={formData.role === 'student' ? 'your.email@student.cuet.ac.bd' : 'vendor@example.com'}
              value={formData.email}
              onChange={handleChange}
              error={errors.email}
            />

            {/* Password Inputs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    name="password"
                    placeholder="At least 8 characters"
                    value={formData.password}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 pr-10 border ${
                      errors.password ? 'border-accent-500' : 'border-gray-300'
                    } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    title={showPassword ? 'Hide' : 'Show'}
                  >
                    {showPassword ? '🙈' : '👁️'}
                  </button>
                </div>
                {errors.password && (
                  <p className="mt-1 text-sm text-accent-600">{errors.password}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm Password
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    name="confirmPassword"
                    placeholder="Repeat password"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 pr-10 border ${
                      errors.confirmPassword ? 'border-accent-500' : 'border-gray-300'
                    } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                    title={showConfirmPassword ? 'Hide' : 'Show'}
                  >
                    {showConfirmPassword ? '🙈' : '👁️'}
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="mt-1 text-sm text-accent-600">{errors.confirmPassword}</p>
                )}
              </div>
            </div>

            {/* Role-Specific Fields */}
            {formData.role === 'student' ? (
              <>
                <Input
                  label="Full Name"
                  type="text"
                  name="name"
                  placeholder="Your full name"
                  value={formData.name}
                  onChange={handleChange}
                  error={errors.name}
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Phone Number"
                    type="tel"
                    name="phone"
                    placeholder="01XXXXXXXXX"
                    value={formData.phone}
                    onChange={handleChange}
                    error={errors.phone}
                  />
                  <Input
                    label="Student ID"
                    type="text"
                    name="studentId"
                    placeholder="e.g., 191-002-001"
                    value={formData.studentId}
                    onChange={handleChange}
                    error={errors.studentId}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input
                    label="Department"
                    type="text"
                    name="department"
                    placeholder="e.g., CSE, ECE, ME"
                    value={formData.department}
                    onChange={handleChange}
                    error={errors.department}
                  />
                  <Input
                    label="Batch"
                    type="text"
                    name="batch"
                    placeholder="e.g., 2023-24"
                    value={formData.batch}
                    onChange={handleChange}
                    error={errors.batch}
                  />
                </div>
              </>
            ) : (
              <>
                <Input
                  label="Business Name"
                  type="text"
                  name="businessName"
                  placeholder="Your restaurant/cafe name"
                  value={formData.businessName}
                  onChange={handleChange}
                  error={errors.businessName}
                />

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Business Description
                  </label>
                  <textarea
                    name="description"
                    placeholder="Describe your business..."
                    value={formData.description}
                    onChange={handleChange}
                    rows="3"
                    className={`w-full px-3 py-2 border ${
                      errors.description ? 'border-accent-500' : 'border-gray-300'
                    } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors`}
                  />
                  {errors.description && (
                    <p className="mt-1 text-sm text-accent-600">{errors.description}</p>
                  )}
                </div>

                <Input
                  label="Contact Number"
                  type="tel"
                  name="contactNumber"
                  placeholder="01XXXXXXXXX"
                  value={formData.contactNumber}
                  onChange={handleChange}
                  error={errors.contactNumber}
                />
              </>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              variant="secondary"
              size="md"
              loading={loading}
              className="w-full"
            >
              {loading ? 'Creating Account...' : 'Create Account'}
            </Button>
          </form>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">already registered?</span>
            </div>
          </div>

          {/* Login Link */}
          <p className="text-center text-gray-700">
            <Link
              to="/login"
              className="text-primary-600 hover:text-primary-700 font-semibold transition-colors"
            >
              Sign in to your account
            </Link>
          </p>
        </div>

        {/* Footer */}
        <p className="text-center text-gray-500 text-xs mt-6">
          © 2026 Smart Campus Ordering. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default Register;