import React, { useState, useEffect } from 'react';
import apiClient from '../../api/client';
import VendorCard from '../../components/student/VendorCard';
import Card from '../../components/ui/Card';

const Vendors = () => {
  const [vendors, setVendors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchVendors = async () => {
      try {
        const response = await apiClient.get('/vendor/all');
        setVendors(response.data);
      } catch (err) {
        setError('Failed to fetch vendors');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchVendors();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <Card className="bg-accent-50 border border-accent-200">
            <p className="text-accent-800"><strong>Error: </strong>{error}</p>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Available Vendors</h1>
          <p className="text-gray-600 mt-2">{vendors.length} vendors available</p>
        </div>
        
        {vendors.length === 0 ? (
          <Card className="text-center py-12">
            <div className="mb-4 text-5xl">🏪</div>
            <p className="text-gray-600">No vendors available at the moment</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {vendors.map(vendor => (
              <VendorCard 
                key={vendor._id} 
                vendor={vendor} 
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Vendors;