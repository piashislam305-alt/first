import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import apiClient from "../../api/client";

export default function Payment() {
  const navigate = useNavigate();
  const { state } = useLocation();

  useEffect(() => {
    const initiatePayment = async () => {
      if (!state?.orderId || !state?.total) {
        navigate("/student/cart");
        return;
      }

      try {
        const res = await apiClient.post("/payment/initiate", {
          orderId: state.orderId,
          amount: state.total,
        });
        window.location.href = res.data.paymentUrl;
      } catch (err) {
        navigate("/student/cart");
      }
    };
    initiatePayment();
  }, [navigate, state]);

  return <div>Redirecting to payment...</div>;
}
