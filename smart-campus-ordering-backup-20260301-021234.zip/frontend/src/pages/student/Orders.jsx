import { useState, useEffect } from "react";
import apiClient from "../../api/client";
import { getSocket, joinStudentRoom } from "../../services/socketService";
import Button from "../../components/ui/Button";
import Badge from "../../components/ui/Badge";
import Card from "../../components/ui/Card";
import { useAuth } from "../../contexts/AuthContext";

export default function StudentOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const { currentUser } = useAuth();

  useEffect(() => {
    fetchOrders();

    // Initialize socket and join room
    if (currentUser?.id) {
      const socket = getSocket();
      joinStudentRoom(currentUser.id);

      // Socket.io listener for real-time updates
      socket.on("orderUpdate", (data) => {
        setOrders(prev => prev.map(order => 
          order._id === data.orderId ? { ...order, status: data.status } : order
        ));
      });

      return () => {
        socket.off("orderUpdate");
      };
    }
  }, [currentUser]);

  const fetchOrders = async () => {
    try {
      const res = await apiClient.get("/orders/student");
      setOrders(res.data);
    } catch (err) {
      console.error("Failed to fetch orders", err);
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async (orderId) => {
    if (!window.confirm("Are you sure you want to cancel this order?")) return;
    
    try {
      await apiClient.put(`/orders/${orderId}/cancel`);
      setOrders(prev => prev.filter(order => order._id !== orderId));
    } catch (err) {
      alert(err.response?.data?.msg || "Cancellation failed");
    }
  };

  const filteredOrders = statusFilter === 'all' 
    ? orders 
    : orders.filter(order => order.status === statusFilter);

  const statusColorMap = {
    pending: 'pending',
    preparing: 'preparing',
    ready: 'ready',
    completed: 'completed',
    cancelled: 'cancelled'
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Orders</h1>
          <p className="text-gray-600">{filteredOrders.length} orders</p>
        </div>

        {/* Status Filter */}
        <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
          {['all', 'pending', 'preparing', 'ready', 'completed', 'cancelled'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                statusFilter === status
                  ? 'bg-primary-600 text-white'
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </button>
          ))}
        </div>

        {/* Orders List */}
        {filteredOrders.length === 0 ? (
          <Card className="text-center py-12">
            <div className="mb-4 text-5xl">📦</div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No orders yet</h3>
            <p className="text-gray-600 mb-6">Start ordering from vendors on the platform</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredOrders.map(order => (
              <Card key={order._id} className="hover:shadow-lg transition-shadow">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      Order #{order._id.slice(-6).toUpperCase()}
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">
                      From: {order.vendorId?.businessName || 'Unknown Vendor'} 
                    </p>
                  </div>
                  <Badge status={statusColorMap[order.status]} size="lg">
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </Badge>
                </div>

                {/* Order Items */}
                <div className="bg-gray-50 rounded-lg p-4 mb-4">
                  <p className="text-sm font-medium text-gray-700 mb-3">Items:</p>
                  <div className="space-y-2">
                    {order.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-sm text-gray-600">
                        <span>{item.quantity}x {item.menuItemId?.name || 'Unknown Item'}</span>
                        <span className="font-medium">৳{(item.menuItemId?.price || 0) * item.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Order Total & Date */}
                <div className="flex justify-between items-center mb-4 pb-4 border-b border-gray-200">
                  <div>
                    <p className="text-sm text-gray-600">Order Date</p>
                    <p className="text-sm font-medium text-gray-900">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Payment: {order.paymentStatus === 'completed' ? 'Paid' : 'Pending'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">Total</p>
                    <p className="text-2xl font-bold text-primary-600">৳{order.total}</p>
                  </div>
                </div>

                {/* Actions */}
                {["pending", "preparing"].includes(order.status) && (
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={() => handleCancel(order._id)}
                  >
                    Cancel Order
                  </Button>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
