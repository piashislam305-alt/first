import React, { useState, useEffect } from 'react';
import apiClient from '../../api/client';
import { Link, useNavigate } from 'react-router-dom';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Badge from '../../components/ui/Badge';

const StudentDashboard = () => {
  const navigate = useNavigate();
  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchRecentOrders = async () => {
      try {
        const response = await apiClient.get('/orders/student?limit=3');
        setRecentOrders(response.data);
      } catch (err) {
        setError('Failed to fetch recent orders');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchRecentOrders();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Welcome Back! 👋</h1>
          <p className="text-gray-600 mt-2">Manage your orders and discover new vendors</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Browse Vendors */}
          <Card className="bg-gradient-to-br from-primary-50 to-primary-100 border border-primary-200 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => navigate('/student/vendors')}>
            <div className="text-center">
              <div className="text-4xl mb-3">🏪</div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">Browse Vendors</h2>
              <p className="text-gray-600 text-sm">Find and order from our campus vendors</p>
              <Button variant="primary" size="sm" className="mt-4 w-full">
                Start Ordering
              </Button>
            </div>
          </Card>

          {/* View Orders */}
          <Card className="bg-gradient-to-br from-secondary-50 to-secondary-100 border border-secondary-200 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => navigate('/student/orders')}>
            <div className="text-center">
              <div className="text-4xl mb-3">📦</div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">Your Orders</h2>
              <p className="text-gray-600 text-sm">Track your order history and status</p>
              <Button variant="secondary" size="sm" className="mt-4 w-full">
                View Orders
              </Button>
            </div>
          </Card>

          {/* Account Settings */}
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => navigate('/student/profile')}>
            <div className="text-center">
              <div className="text-4xl mb-3">⚙️</div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">Account</h2>
              <p className="text-gray-600 text-sm">Manage your account and preferences</p>
              <Button variant="outline" size="sm" className="mt-4 w-full">
                Settings
              </Button>
            </div>
          </Card>
        </div>

        {/* Recent Orders Section */}
        <Card>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6 pb-6 border-b border-gray-200">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">Recent Orders</h2>
              <p className="text-gray-600 text-sm mt-1">Your latest orders and their status</p>
            </div>
            <Link to="/student/orders" className="text-primary-600 hover:text-primary-700 font-medium">
              View All →
            </Link>
          </div>

          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary-600"></div>
            </div>
          ) : error ? (
            <div className="bg-accent-50 border border-accent-200 rounded-lg p-4">
              <p className="text-accent-800">{error}</p>
            </div>
          ) : recentOrders.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-5xl mb-3">📭</div>
              <p className="text-gray-600">You haven't placed any orders yet</p>
              <Button 
                variant="primary" 
                size="sm" 
                className="mt-4"
                onClick={() => navigate('/student/vendors')}
              >
                Browse Vendors
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {recentOrders.map(order => (
                <div key={order._id} className="border border-gray-200 rounded-lg p-4 hover:border-primary-300 transition-colors">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900">Order #{order._id.slice(-6).toUpperCase()}</p>
                      <p className="text-sm text-gray-600 mt-1">
                        {order.vendorId?.businessName || 'Unknown Vendor'} • {new Date(order.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge status={order.status}>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </Badge>
                      <p className="font-bold text-primary-600 whitespace-nowrap">৳{(order.total || 0).toFixed(0)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default StudentDashboard;