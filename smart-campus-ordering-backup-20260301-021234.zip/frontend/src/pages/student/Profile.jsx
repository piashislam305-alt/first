import React, { useEffect, useState } from 'react';
import apiClient from '../../api/client';
import Button from '../../components/ui/Button';
import Card from '../../components/ui/Card';

const StudentProfile = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [passwordSaving, setPasswordSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    name: '',
    phone: '',
    department: '',
    batch: '',
    studentId: ''
  });
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: ''
  });

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get('/student/profile');
      setForm({
        name: response.data.name || '',
        phone: response.data.phone || '',
        department: response.data.department || '',
        batch: response.data.batch || '',
        studentId: response.data.studentId || ''
      });
    } catch (err) {
      setError(err.response?.data?.msg || 'Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleProfileSave = async (event) => {
    event.preventDefault();
    try {
      setSaving(true);
      setMessage('');
      setError('');
      await apiClient.put('/student/profile', form);
      setMessage('Profile updated successfully');
    } catch (err) {
      setError(err.response?.data?.msg || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handlePasswordChange = async (event) => {
    event.preventDefault();
    try {
      setPasswordSaving(true);
      setMessage('');
      setError('');
      await apiClient.put('/student/change-password', passwordForm);
      setPasswordForm({ currentPassword: '', newPassword: '' });
      setMessage('Password updated successfully');
    } catch (err) {
      setError(err.response?.data?.msg || 'Failed to update password');
    } finally {
      setPasswordSaving(false);
    }
  };

  if (loading) {
    return <div className="py-10 text-center text-gray-600">Loading profile...</div>;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Student Profile</h1>

      {(message || error) && (
        <Card className={error ? 'border border-accent-200 bg-accent-50' : 'border border-secondary-200 bg-secondary-50'}>
          <p className={error ? 'text-accent-800' : 'text-secondary-800'}>{error || message}</p>
        </Card>
      )}

      <Card>
        <h2 className="mb-4 text-xl font-semibold text-gray-900">Basic Information</h2>
        <form className="grid grid-cols-1 gap-3 md:grid-cols-2" onSubmit={handleProfileSave}>
          <input className="rounded-lg border border-gray-300 px-3 py-2" placeholder="Name" value={form.name} onChange={(e) => setForm((s) => ({ ...s, name: e.target.value }))} />
          <input className="rounded-lg border border-gray-300 px-3 py-2" placeholder="Phone" value={form.phone} onChange={(e) => setForm((s) => ({ ...s, phone: e.target.value }))} />
          <input className="rounded-lg border border-gray-300 px-3 py-2" placeholder="Department" value={form.department} onChange={(e) => setForm((s) => ({ ...s, department: e.target.value }))} />
          <input className="rounded-lg border border-gray-300 px-3 py-2" placeholder="Batch" value={form.batch} onChange={(e) => setForm((s) => ({ ...s, batch: e.target.value }))} />
          <input className="rounded-lg border border-gray-300 px-3 py-2 md:col-span-2" placeholder="Student ID" value={form.studentId} onChange={(e) => setForm((s) => ({ ...s, studentId: e.target.value }))} />
          <div className="md:col-span-2">
            <Button type="submit" loading={saving}>Save Profile</Button>
          </div>
        </form>
      </Card>

      <Card>
        <h2 className="mb-4 text-xl font-semibold text-gray-900">Change Password</h2>
        <form className="grid grid-cols-1 gap-3 md:grid-cols-2" onSubmit={handlePasswordChange}>
          <input
            type="password"
            className="rounded-lg border border-gray-300 px-3 py-2"
            placeholder="Current Password"
            value={passwordForm.currentPassword}
            onChange={(e) => setPasswordForm((s) => ({ ...s, currentPassword: e.target.value }))}
          />
          <input
            type="password"
            className="rounded-lg border border-gray-300 px-3 py-2"
            placeholder="New Password"
            value={passwordForm.newPassword}
            onChange={(e) => setPasswordForm((s) => ({ ...s, newPassword: e.target.value }))}
          />
          <div className="md:col-span-2">
            <Button type="submit" variant="outline" loading={passwordSaving}>Update Password</Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default StudentProfile;
