import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import apiClient from '../../api/client';
import { useCart } from '../../contexts/CartContext';
import MenuItem from '../../components/student/MenuItem';
import Badge from '../../components/ui/Badge';
import Card from '../../components/ui/Card';

const VendorMenu = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart, setVendor, vendorId, clearCart, totalItems } = useCart();
  const [vendorData, setVendorData] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchVendorAndMenu = async () => {
      try {
        setLoading(true);

        // Fetch vendor details
        const vendorResponse = await apiClient.get(`/vendor/${id}`);
        setVendorData(vendorResponse.data);

        // Fetch menu items
        const menuResponse = await apiClient.get(`/menu/vendor/${id}`);
        setMenuItems(menuResponse.data);
      } catch (err) {
        setError('Failed to fetch vendor menu');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchVendorAndMenu();
  }, [id]);

  // Ensure user is ordering from a single vendor
  useEffect(() => {
    if (!vendorId) {
      setVendor(id);
      return;
    }

    if (vendorId !== id) {
      if (window.confirm('You have items from another vendor in your cart. Start a new order?')) {
        clearCart();
        setVendor(id);
      } else {
        navigate('/student/cart');
      }
    }
  }, [id, vendorId, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <Card className="bg-accent-50 border border-accent-200">
            <p className="text-accent-800"><strong>Error: </strong>{error}</p>
          </Card>
        </div>
      </div>
    );
  }

  if (!vendorData) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Vendor Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{vendorData.businessName}</h1>
            <p className="text-gray-600 mt-2">{vendorData.description}</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => navigate('/student/cart')}
              className="rounded-lg bg-primary-600 px-4 py-2 font-medium text-white hover:bg-primary-700"
            >
              Cart ({totalItems})
            </button>
            <Badge status={vendorData.isActive ? 'open' : 'closed'} size="lg">
              {vendorData.isActive ? 'Open' : 'Closed'}
            </Badge>
          </div>
        </div>

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {menuItems.length === 0 ? (
            <div className="col-span-full">
              <Card className="text-center py-12">
                <div className="mb-4 text-5xl">🍽️</div>
                <p className="text-gray-600">No menu items available</p>
              </Card>
            </div>
          ) : (
            menuItems.map(item => (
              <MenuItem 
                key={item._id} 
                item={item} 
                onAddToCart={addToCart}
                isAvailable={item.isAvailable}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default VendorMenu;
