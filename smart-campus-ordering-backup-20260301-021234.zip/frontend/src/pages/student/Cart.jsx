import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../../contexts/CartContext';
import CartItem from '../../components/student/CartItem';
import Button from '../../components/ui/Button';
import apiClient from '../../api/client';
import MockPaymentModal from '../../components/student/MockPaymentModal';

const Cart = () => {
  const navigate = useNavigate();
  const [placingOrder, setPlacingOrder] = React.useState(false);
  const [showPaymentModal, setShowPaymentModal] = React.useState(false);
  const [checkoutError, setCheckoutError] = React.useState('');
  const { 
    cart, 
    vendorId, 
    removeFromCart, 
    updateQuantity, 
    clearCart, 
    totalItems, 
    totalPrice 
  } = useCart();

  const handleCheckout = async () => {
    if (!vendorId) {
      setCheckoutError('Vendor information is missing. Please return to a vendor menu and add items again.');
      return;
    }

    if (cart.length === 0) {
      setCheckoutError('Your cart is empty.');
      return;
    }

    setCheckoutError('');
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = async () => {
    try {
      setPlacingOrder(true);
      setCheckoutError('');

      const payload = {
        vendorId,
        items: cart.map(item => ({
          menuItemId: item._id,
          quantity: item.quantity
        })),
        paymentStatus: 'completed'
      };

      const response = await apiClient.post('/orders', payload);
      clearCart();
      setShowPaymentModal(false);
      navigate('/student/orders', { state: { createdOrderId: response.data._id } });
    } catch (err) {
      setCheckoutError(err.response?.data?.msg || 'Failed to place order');
    } finally {
      setPlacingOrder(false);
    }
  };

  if (totalItems === 0) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Your Cart is Empty</h1>
        <p className="text-gray-600 mb-6">
          Browse our vendors and add some delicious items to your cart!
        </p>
        <Button onClick={() => navigate('/student/vendors')}>
          Browse Vendors
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Your Cart</h1>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="divide-y divide-gray-200">
              {cart.map(item => (
                <CartItem
                  key={item._id}
                  item={item}
                  onRemove={() => removeFromCart(item._id)}
                  onUpdateQuantity={(quantity) => updateQuantity(item._id, quantity)}
                />
              ))}
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold mb-4">Order Summary</h2>

            {checkoutError && (
              <div className="mb-4 rounded-lg border border-accent-200 bg-accent-50 p-3 text-sm text-accent-800">
                {checkoutError}
              </div>
            )}
            
            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>${totalPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Fee</span>
                <span>$0.00</span>
              </div>
              <div className="flex justify-between font-bold text-lg border-t pt-3">
                <span>Total</span>
                <span>${totalPrice.toFixed(2)}</span>
              </div>
            </div>
            
            <Button 
              onClick={handleCheckout}
              className="w-full py-3"
              disabled={cart.length === 0 || placingOrder}
            >
              {placingOrder ? 'Placing Order...' : 'Proceed to Payment'}
            </Button>
            
            <button
              onClick={clearCart}
              className="mt-3 text-sm text-red-600 hover:text-red-800 w-full text-center"
            >
              Clear Cart
            </button>
          </div>
        </div>
      </div>

      <MockPaymentModal
        open={showPaymentModal}
        amount={totalPrice}
        onClose={() => setShowPaymentModal(false)}
        onSuccess={handlePaymentSuccess}
      />
    </div>
  );
};

export default Cart;
