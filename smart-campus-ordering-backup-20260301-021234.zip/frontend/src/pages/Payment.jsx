import React, { useState } from 'react';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Modal from '../../components/ui/Modal';
import Badge from '../../components/ui/Badge';
import {
  validateCardNumber,
  validateCVV,
  validateExpiryDate,
  detectCardType,
  processPayment,
} from '../../services/paymentService';

const Payment = ({ orderTotal = 0, orderId = '', onPaymentSuccess = () => {}, onClose = () => {} }) => {
  const [cardData, setCardData] = useState({
    cardNumber: '',
    cardholderName: '',
    expiryMonth: '',
    expiryYear: new Date().getFullYear().toString(),
    cvv: '',
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState(null); // 'processing', 'success', 'error'
  const [paymentResult, setPaymentResult] = useState(null);

  const handleCardInputChange = (e) => {
    const { name, value } = e.target;
    let formattedValue = value;

    // Format card number with spaces
    if (name === 'cardNumber') {
      formattedValue = value.replace(/\s+/g, '').replace(/(\d{4})/g, '$1 ').trim();
    }

    // Limit CVV to 4 digits
    if (name === 'cvv') {
      formattedValue = value.replace(/\D/g, '').slice(0, 4);
    }

    // Uppercase cardholder name
    if (name === 'cardholderName') {
      formattedValue = value.toUpperCase();
    }

    setCardData((prev) => ({ ...prev, [name]: formattedValue }));

    // Clear errors as user types
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!cardData.cardNumber || !validateCardNumber(cardData.cardNumber)) {
      newErrors.cardNumber = 'Invalid card number';
    }

    if (!cardData.cardholderName || cardData.cardholderName.length < 2) {
      newErrors.cardholderName = 'Cardholder name is required';
    }

    if (!cardData.expiryMonth) {
      newErrors.expiryMonth = 'Expiry month is required';
    }

    if (!cardData.expiryYear) {
      newErrors.expiryYear = 'Expiry year is required';
    }

    if (!cardData.cvv || !validateCVV(cardData.cvv)) {
      newErrors.cvv = 'CVV must be 3-4 digits';
    }

    if (!validateExpiryDate(cardData.expiryMonth, cardData.expiryYear)) {
      newErrors.expiryMonth = 'Card has expired';
    }

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const newErrors = validateForm();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      setLoading(true);
      setPaymentStatus('processing');

      const result = await processPayment({
        cardNumber: cardData.cardNumber,
        cardholderName: cardData.cardholderName,
        expiryMonth: cardData.expiryMonth,
        expiryYear: cardData.expiryYear,
        cvv: cardData.cvv,
        amount: orderTotal,
        description: `Order ${orderId}`,
      });

      setPaymentStatus('success');
      setPaymentResult(result);
      setTimeout(() => onPaymentSuccess(result), 2000);
    } catch (error) {
      setPaymentStatus('error');
      setPaymentResult({ error: error.message });
    } finally {
      setLoading(false);
    }
  };

  const cardType = detectCardType(cardData.cardNumber);
  const cardIcons = {
    visa: '💳',
    mastercard: '💳',
    amex: '💳',
    discover: '💳',
    unknown: '💳',
  };

  // Success Screen
  if (paymentStatus === 'success' && paymentResult) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-xl shadow-lg max-w-md w-full p-8 text-center animate-fade-in">
          <div className="mb-6">
            <div className="w-16 h-16 bg-secondary-100 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
              <span className="text-3xl">✓</span>
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Payment Successful!</h2>
          </div>

          <div className="bg-gray-50 rounded-lg p-4 mb-6 text-left space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Transaction ID</span>
              <span className="font-mono text-sm text-gray-900">{paymentResult.transactionId}</span>
            </div>
            <div className="border-t border-gray-200 pt-3 flex justify-between">
              <span className="text-gray-600">Amount</span>
              <span className="font-bold text-gray-900">৳{paymentResult.amount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Card</span>
              <span className="text-gray-900">
                {cardIcons[paymentResult.cardType]} ••••{paymentResult.last4}
              </span>
            </div>
          </div>

          <p className="text-sm text-gray-600 mb-6">
            A confirmation email has been sent to your registered email address.
          </p>

          <Button
            variant="primary"
            size="md"
            className="w-full"
            onClick={() => onClose()}
          >
            Done
          </Button>
        </div>
      </div>
    );
  }

  // Error Screen
  if (paymentStatus === 'error' && paymentResult) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-xl shadow-lg max-w-md w-full p-8 text-center animate-fade-in">
          <div className="mb-6">
            <div className="w-16 h-16 bg-accent-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <span className="text-3xl">✕</span>
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Payment Failed</h2>
          </div>

          <div className="bg-accent-50 border border-accent-200 rounded-lg p-4 mb-6">
            <p className="text-accent-800">{paymentResult.error}</p>
          </div>

          <p className="text-sm text-gray-600 mb-6">
            Please check your card details and try again. If the problem persists, try a different payment method.
          </p>

          <Button
            variant="primary"
            size="md"
            className="w-full"
            onClick={() => {
              setPaymentStatus(null);
              setPaymentResult(null);
            }}
          >
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  // Payment Form
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-white rounded-xl shadow-lg max-w-md w-full max-h-[90vh] overflow-y-auto animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Complete Payment</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6">
          {/* Order Summary */}
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-600">Order Total</p>
                <p className="text-2xl font-bold text-gray-900">৳{orderTotal}</p>
              </div>
              <Badge status="pending">Pending</Badge>
            </div>
            {orderId && (
              <p className="text-xs text-gray-600 mt-2">Order ID: {orderId}</p>
            )}
          </div>

          {/* Payment Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Cardholder Name */}
            <Input
              label="Cardholder Name"
              type="text"
              name="cardholderName"
              placeholder="JOHN DOE"
              value={cardData.cardholderName}
              onChange={handleCardInputChange}
              error={errors.cardholderName}
              disabled={loading}
            />

            {/* Card Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Card Number
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  value={cardData.cardNumber}
                  onChange={handleCardInputChange}
                  disabled={loading}
                  className={`w-full px-3 py-2 pr-10 border ${
                    errors.cardNumber ? 'border-accent-500' : 'border-gray-300'
                  } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors`}
                  maxLength="23"
                />
                {cardData.cardNumber && (
                  <span className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xl">
                    {cardIcons[cardType]}
                  </span>
                )}
              </div>
              {cardData.cardNumber && (
                <p className="text-xs text-gray-500 mt-1">
                  {cardType !== 'unknown' ? `${cardType.toUpperCase()} card` : 'Unknown card type'}
                </p>
              )}
              {errors.cardNumber && (
                <p className="text-sm text-accent-600 mt-1">{errors.cardNumber}</p>
              )}
            </div>

            {/* Expiry & CVV */}
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Month
                </label>
                <select
                  name="expiryMonth"
                  value={cardData.expiryMonth}
                  onChange={handleCardInputChange}
                  disabled={loading}
                  className={`w-full px-3 py-2 border ${
                    errors.expiryMonth ? 'border-accent-500' : 'border-gray-300'
                  } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors`}
                >
                  <option value="">MM</option>
                  {Array.from({ length: 12 }, (_, i) => i + 1).map((month) => (
                    <option key={month} value={month.toString().padStart(2, '0')}>
                      {month.toString().padStart(2, '0')}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Year
                </label>
                <select
                  name="expiryYear"
                  value={cardData.expiryYear}
                  onChange={handleCardInputChange}
                  disabled={loading}
                  className={`w-full px-3 py-2 border ${
                    errors.expiryYear ? 'border-accent-500' : 'border-gray-300'
                  } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors`}
                >
                  {Array.from({ length: 15 }, (_, i) => new Date().getFullYear() + i).map(
                    (year) => (
                      <option key={year} value={year.toString()}>
                        {year.toString().slice(-2)}
                      </option>
                    )
                  )}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  CVV
                </label>
                <input
                  type="text"
                  name="cvv"
                  placeholder="123"
                  value={cardData.cvv}
                  onChange={handleCardInputChange}
                  disabled={loading}
                  className={`w-full px-3 py-2 border ${
                    errors.cvv ? 'border-accent-500' : 'border-gray-300'
                  } rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-primary-500 transition-colors`}
                />
                {errors.cvv && (
                  <p className="text-xs text-accent-600 mt-1">{errors.cvv}</p>
                )}
              </div>
            </div>

            {/* Security Notice */}
            <div className="bg-gray-50 rounded-lg p-3 flex items-start gap-3">
              <span className="text-xl">🔒</span>
              <div>
                <p className="text-xs font-medium text-gray-700">Your payment is secure</p>
                <p className="text-xs text-gray-500">Encrypted and sent securely</p>
              </div>
            </div>

            {/* Terms */}
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                required
                className="w-4 h-4 text-primary-600 border-gray-300 rounded focus:ring-primary-500"
              />
              <span className="text-xs text-gray-600">
                I agree to the <span className="font-medium">Terms & Conditions</span>
              </span>
            </label>

            {/* Submit Button */}
            <Button
              type="submit"
              variant="primary"
              size="md"
              loading={loading}
              disabled={loading}
              className="w-full"
            >
              {paymentStatus === 'processing' ? 'Processing...' : `Pay ৳${orderTotal}`}
            </Button>
          </form>

          {/* Test Cards Info */}
          <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
            <p className="text-xs font-medium text-blue-900 mb-2">Test Cards (Mock Mode)</p>
            <div className="space-y-1 text-xs text-blue-800 font-mono">
              <p>• 4242 4242 4242 4242 (Visa)</p>
              <p>• 5555 5555 5555 4444 (Mastercard)</p>
              <p>Any future date • Any CVV</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payment;
