import React, { useEffect, useState } from 'react';
import apiClient from '../../api/client';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

const AdminDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [users, setUsers] = useState([]);
  const [analytics, setAnalytics] = useState({
    totalUsers: 0,
    totalVendors: 0,
    totalOrders: 0,
    totalRevenue: 0
  });

  const fetchAdminData = async () => {
    try {
      setLoading(true);
      setError('');
      const [usersRes, analyticsRes] = await Promise.all([
        apiClient.get('/admin/users'),
        apiClient.get('/admin/analytics')
      ]);
      setUsers(usersRes.data || []);
      setAnalytics(analyticsRes.data || analytics);
    } catch (err) {
      setError(err.response?.data?.msg || err.response?.data?.error || 'Failed to load admin data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, []);

  const toggleUserStatus = async (userId) => {
    try {
      const response = await apiClient.put(`/admin/users/${userId}/status`);
      setUsers((prev) => prev.map((user) => (user._id === userId ? response.data : user)));
    } catch (err) {
      setError(err.response?.data?.msg || 'Failed to update user status');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">System Overview</h1>
      </div>

      {error && (
        <Card className="border border-accent-200 bg-accent-50">
          <p className="text-accent-800 text-sm">{error}</p>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <p className="text-sm text-gray-500">Total Users</p>
          <p className="text-2xl font-bold text-gray-900">{analytics.totalUsers}</p>
        </Card>
        <Card>
          <p className="text-sm text-gray-500">Total Vendors</p>
          <p className="text-2xl font-bold text-gray-900">{analytics.totalVendors}</p>
        </Card>
        <Card>
          <p className="text-sm text-gray-500">Total Orders</p>
          <p className="text-2xl font-bold text-gray-900">{analytics.totalOrders}</p>
        </Card>
        <Card>
          <p className="text-sm text-gray-500">Revenue</p>
          <p className="text-2xl font-bold text-gray-900">৳{analytics.totalRevenue}</p>
        </Card>
      </div>

      <Card>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Users</h2>
          <Button variant="outline" size="sm" onClick={fetchAdminData}>
            Refresh
          </Button>
        </div>

        {users.length === 0 ? (
          <p className="text-gray-600">No users found.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="text-left border-b">
                  <th className="py-2 pr-3">Email</th>
                  <th className="py-2 pr-3">Role</th>
                  <th className="py-2 pr-3">Status</th>
                  <th className="py-2">Action</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user._id} className="border-b">
                    <td className="py-2 pr-3">{user.email}</td>
                    <td className="py-2 pr-3 capitalize">{user.role}</td>
                    <td className="py-2 pr-3">{user.isActive ? 'Active' : 'Blocked'}</td>
                    <td className="py-2">
                      <Button
                        size="sm"
                        variant={user.isActive ? 'danger' : 'success'}
                        onClick={() => toggleUserStatus(user._id)}
                      >
                        {user.isActive ? 'Block' : 'Activate'}
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
};

export default AdminDashboard;
