import axios from 'axios';
import { clearAuthToken, getAuthTokenWithSource } from '../utils/authStorage';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const createApiClient = () => {
  const client = axios.create({
    baseURL: API_URL,
    headers: {
      'Content-Type': 'application/json'
    }
  });

  // Add token to requests
  client.interceptors.request.use((config) => {
    const { token, source } = getAuthTokenWithSource();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
      config.authTokenSource = source;
    }
    return config;
  });

  // Handle response errors
  client.interceptors.response.use(
    response => response,
    error => {
      if (error.response?.status === 401) {
        clearAuthToken(error.config?.authTokenSource || null);
        window.location.href = '/login';
      }
      return Promise.reject(error);
    }
  );

  return client;
};

export const apiClient = createApiClient();

export default apiClient;
