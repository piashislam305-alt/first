import apiClient from './client';

// Create a new order
export const createOrder = async (orderData) => {
  try {
    const response = await apiClient.post('/orders', orderData);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Get orders for current student
export const getStudentOrders = async () => {
  try {
    const response = await apiClient.get('/orders/student');
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Get orders for current vendor
export const getVendorOrders = async () => {
  try {
    const response = await apiClient.get('/orders/vendor');
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Update order status
export const updateOrderStatus = async (orderId, status) => {
  try {
    const response = await apiClient.put(`/orders/${orderId}`, { status });
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Cancel order
export const cancelOrder = async (orderId) => {
  try {
    const response = await apiClient.put(`/orders/${orderId}/cancel`);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};