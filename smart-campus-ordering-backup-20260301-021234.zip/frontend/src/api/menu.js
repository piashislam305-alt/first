import apiClient from './client';

// Get vendor's own menu
export const getMyVendorMenu = async () => {
  try {
    const response = await apiClient.get('/menu/vendor');
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Create menu item
export const createMenuItem = async (itemData) => {
  try {
    const response = await apiClient.post('/menu', itemData);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Update menu item
export const updateMenuItem = async (id, itemData) => {
  try {
    const response = await apiClient.put(`/menu/${id}`, itemData);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Delete menu item
export const deleteMenuItem = async (id) => {
  try {
    const response = await apiClient.delete(`/menu/${id}`);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};