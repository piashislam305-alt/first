import apiClient from './client';

// Initiate payment
export const initiatePayment = async (orderId, amount) => {
  try {
    const response = await apiClient.post('/payment/initiate', {
      orderId,
      amount
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Verify payment
export const verifyPayment = async (orderId) => {
  try {
    const response = await apiClient.get(`/payment/verify/${orderId}`);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};
