import apiClient from './client';

// Get all vendors
export const getVendors = async () => {
  try {
    const response = await apiClient.get('/vendor/all');
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Get single vendor
export const getVendor = async (id) => {
  try {
    const response = await apiClient.get(`/vendor/${id}`);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Get vendor profile
export const getVendorProfile = async () => {
  try {
    const response = await apiClient.get('/vendor/profile');
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Update vendor profile
export const updateVendorProfile = async (data) => {
  try {
    const response = await apiClient.put('/vendor/profile', data);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Update vendor schedule
export const updateVendorSchedule = async (schedule, isOpen) => {
  try {
    const response = await apiClient.put('/vendor/schedule', { schedule, isOpen });
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Get vendor dashboard analytics
export const getVendorAnalytics = async () => {
  try {
    const response = await apiClient.get('/vendor/dashboard/analytics');
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};