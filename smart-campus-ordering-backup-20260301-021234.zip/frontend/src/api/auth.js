import apiClient from './client';

// Login user
export const login = async (email, password) => {
  try {
    const response = await apiClient.post('/auth/login', { email, password });
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Register user
export const register = async (email, password, role, additionalData) => {
  try {
    const response = await apiClient.post('/auth/register', {
      email,
      password,
      role,
      ...additionalData
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Get current user
export const getCurrentUser = async () => {
  try {
    const response = await apiClient.get('/auth/user');
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};