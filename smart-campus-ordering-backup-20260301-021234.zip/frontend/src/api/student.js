import apiClient from './client';

// Get student profile
export const getStudentProfile = async () => {
  try {
    const response = await apiClient.get('/student/profile');
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Update student profile
export const updateStudentProfile = async (data) => {
  try {
    const response = await apiClient.put('/student/profile', data);
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};

// Change password
export const changePassword = async (currentPassword, newPassword) => {
  try {
    const response = await apiClient.put('/student/change-password', {
      currentPassword,
      newPassword
    });
    return response.data;
  } catch (error) {
    throw error.response?.data || error.message;
  }
};
