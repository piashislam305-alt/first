import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';

// Layouts
import StudentLayout from './layouts/StudentLayout';
import VendorLayout from './layouts/VendorLayout';
import AdminLayout from './layouts/AdminLayout';

// Pages
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import StudentDashboard from './pages/student/Dashboard';
import Vendors from './pages/student/Vendors';
import VendorMenu from './pages/student/Menu';
import Cart from './pages/student/Cart';
import Orders from './pages/student/Orders';
import StudentProfile from './pages/student/Profile';
import VendorDashboard from './pages/vendor/Dashboard';
import MenuManagement from './pages/vendor/MenuManagement';
import VendorOrders from './pages/vendor/Orders';
import Schedule from './pages/vendor/Schedule';
import VendorProfile from './pages/vendor/Profile';
import VendorAnalytics from './pages/vendor/Analytics';
import AdminDashboard from './pages/admin/Dashboard';

const PrivateRoute = ({ children, role }) => {
  const { currentUser } = useAuth();
  
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  
  if (role && currentUser.role !== role) {
    return <Navigate to="/" replace />;
  }
  
  return children;
};

const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      
      {/* Student Routes */}
      <Route path="/student" element={
        <PrivateRoute role="student">
          <StudentLayout />
        </PrivateRoute>
      }>
        <Route index element={<StudentDashboard />} />
        <Route path="vendors" element={<Vendors />} />
        <Route path="vendor/:id/menu" element={<VendorMenu />} />
        <Route path="cart" element={<Cart />} />
        <Route path="orders" element={<Orders />} />
        <Route path="profile" element={<StudentProfile />} />
      </Route>
      
      {/* Vendor Routes */}
      <Route path="/vendor" element={
        <PrivateRoute role="vendor">
          <VendorLayout />
        </PrivateRoute>
      }>
        <Route index element={<VendorDashboard />} />
        <Route path="menu" element={<MenuManagement />} />
        <Route path="orders" element={<VendorOrders />} />
        <Route path="schedule" element={<Schedule />} />
        <Route path="profile" element={<VendorProfile />} />
        <Route path="analytics" element={<VendorAnalytics />} />
      </Route>

      {/* Admin Routes */}
      <Route path="/admin" element={
        <PrivateRoute role="admin">
          <AdminLayout />
        </PrivateRoute>
      }>
        <Route index element={<AdminDashboard />} />
      </Route>
      
      {/* Default Route */}
      <Route path="/" element={<Navigate to="/register" replace />} />
    </Routes>
  );
};

export default AppRoutes;
