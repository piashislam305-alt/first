import React from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const StudentLayout = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-blue-600 text-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold">Campus Eats</h1>
          <nav className="flex space-x-4">
            <Link to="/student" className="hover:underline">Dashboard</Link>
            <Link to="/student/vendors" className="hover:underline">Vendors</Link>
            <Link to="/student/cart" className="hover:underline">Cart</Link>
            <Link to="/student/orders" className="hover:underline">My Orders</Link>
            <Link to="/student/profile" className="hover:underline">Profile</Link>
            <button 
              onClick={handleLogout}
              className="hover:underline"
            >
              Logout
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-6">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-gray-100 py-4">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© {new Date().getFullYear()} Campus Eats - CUET Smart Campus Ordering System</p>
        </div>
      </footer>
    </div>
  );
};

export default StudentLayout;
