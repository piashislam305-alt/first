import React from 'react';
import { Link, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const VendorLayout = () => {
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="bg-green-600 text-white shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-bold">Vendor Dashboard</h1>
          <nav className="flex space-x-4">
            <Link to="/vendor" className="hover:underline">Overview</Link>
            <Link to="/vendor/menu" className="hover:underline">Menu</Link>
            <Link to="/vendor/orders" className="hover:underline">Orders</Link>
            <Link to="/vendor/schedule" className="hover:underline">Schedule</Link>
            <Link to="/vendor/analytics" className="hover:underline">Analytics</Link>
            <Link to="/vendor/profile" className="hover:underline">Profile</Link>
            <button 
              onClick={handleLogout}
              className="hover:underline"
            >
              Logout
            </button>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-6">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-gray-100 py-4">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© {new Date().getFullYear()} Campus Eats Vendor Portal</p>
        </div>
      </footer>
    </div>
  );
};

export default VendorLayout;
