import React from 'react';

const Badge = ({ 
  children, 
  status = 'default',
  size = 'md',
  className = '' 
}) => {
  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-2.5 py-0.5 text-xs',
    lg: 'px-3 py-1 text-sm',
  };

  const statusClasses = {
    pending: 'bg-yellow-100 text-yellow-800',
    preparing: 'bg-blue-100 text-blue-800',
    ready: 'bg-green-100 text-green-800',
    completed: 'bg-secondary-100 text-secondary-800',
    cancelled: 'bg-accent-100 text-accent-800',
    active: 'bg-secondary-100 text-secondary-800',
    inactive: 'bg-gray-100 text-gray-800',
    open: 'bg-secondary-100 text-secondary-800',
    closed: 'bg-accent-100 text-accent-800',
    default: 'bg-gray-100 text-gray-800',
  };

  return (
    <span
      className={`inline-flex items-center rounded-full font-medium ${sizeClasses[size]} ${statusClasses[status]} ${className}`}
    >
      {children}
    </span>
  );
};

export default Badge;
