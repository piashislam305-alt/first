import React from 'react';

const Input = React.forwardRef(({
  label,
  error,
  className = '',
  size = 'md',
  type = 'text',
  disabled = false,
  ...props
}, ref) => {
  const sizeClasses = {
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-3 py-2 text-base',
    lg: 'px-4 py-3 text-lg',
  };

  return (
    <div className="w-full">
      {label && (
        <label className="block text-sm font-medium text-gray-700 mb-1">
          {label}
        </label>
      )}
      <input
        ref={ref}
        type={type}
        disabled={disabled}
        className={`
          w-full
          ${sizeClasses[size]}
          border
          ${error ? 'border-accent-500 focus:ring-accent-500 focus:border-accent-500' : 'border-gray-300 focus:ring-primary-500 focus:border-primary-500'}
          rounded-md
          shadow-sm
          placeholder-gray-400
          focus:outline-none
          focus:ring-2
          transition-colors
          disabled:bg-gray-100
          disabled:cursor-not-allowed
          ${className}
        `}
        {...props}
      />
      {error && (
        <p className="mt-1 text-sm text-accent-600">
          {error}
        </p>
      )}
    </div>
  );
});

Input.displayName = 'Input';

export default Input;
