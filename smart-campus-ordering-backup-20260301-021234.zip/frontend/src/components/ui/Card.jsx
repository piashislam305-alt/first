import React from 'react';

const Card = ({ 
  children, 
  className = '', 
  hoverable = false,
  onClick = null 
}) => {
  return (
    <div
      className={`bg-white rounded-lg shadow-soft hover:shadow-medium transition-shadow p-6 ${hoverable ? 'cursor-pointer hover:scale-105' : ''} ${className}`}
      onClick={onClick}
    >
      {children}
    </div>
  );
};

export default Card;
