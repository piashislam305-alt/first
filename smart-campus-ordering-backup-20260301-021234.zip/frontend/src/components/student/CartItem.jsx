import React from 'react';

const CartItem = ({ item, onRemove, onUpdateQuantity }) => {
  return (
    <div className="flex items-center p-4">
      <div className="flex-grow">
        <h3 className="font-semibold">{item.name}</h3>
        <p className="text-gray-600 text-sm">${item.price.toFixed(2)}</p>
      </div>
      
      <div className="flex items-center space-x-2">
        <button
          onClick={() => onUpdateQuantity(item.quantity - 1)}
          className="w-8 h-8 flex items-center justify-center bg-gray-200 rounded-full"
        >
          -
        </button>
        
        <span className="w-10 text-center">{item.quantity}</span>
        
        <button
          onClick={() => onUpdateQuantity(item.quantity + 1)}
          className="w-8 h-8 flex items-center justify-center bg-gray-200 rounded-full"
        >
          +
        </button>
      </div>
      
      <div className="ml-4 font-semibold">
        ${(item.price * item.quantity).toFixed(2)}
      </div>
      
      <button
        onClick={() => onRemove(item._id)}
        className="ml-4 text-red-600 hover:text-red-800"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
        </svg>
      </button>
    </div>
  );
};

export default CartItem;