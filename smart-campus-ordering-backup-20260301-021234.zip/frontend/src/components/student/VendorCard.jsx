import React from 'react';
import { Link } from 'react-router-dom';

const VendorCard = ({ vendor }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="p-4">
        <div className="flex items-center mb-3">
          {vendor.logo ? (
            <img 
              src={vendor.logo} 
              alt={vendor.businessName} 
              className="w-16 h-16 rounded-full object-cover mr-4"
            />
          ) : (
            <div className="bg-gray-200 border-2 border-dashed rounded-xl w-16 h-16 mr-4" />
          )}
          <div>
            <h3 className="font-bold text-lg">{vendor.businessName}</h3>
            <div className={`px-2 py-1 rounded-full text-xs inline-block ${
              vendor.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
            }`}>
              {vendor.isActive ? 'Open' : 'Closed'}
            </div>
          </div>
        </div>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {vendor.description || 'No description available'}
        </p>
        
        <Link 
          to={`/student/vendor/${vendor._id}/menu`}
          className={`block text-center py-2 px-4 rounded ${
            vendor.isActive 
              ? 'bg-blue-600 text-white hover:bg-blue-700' 
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
          }`}
          disabled={!vendor.isActive}
        >
          {vendor.isActive ? 'View Menu' : 'Currently Closed'}
        </Link>
      </div>
    </div>
  );
};

export default VendorCard;