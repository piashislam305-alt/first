import React, { useMemo, useState } from 'react';
import Button from '../ui/Button';
import {
  validateCardNumber,
  validateCVV,
  validateExpiryDate,
  processPayment
} from '../../services/paymentService';

const currentYear = new Date().getFullYear();

const MockPaymentModal = ({ open, amount, onClose, onSuccess }) => {
  const [cardNumber, setCardNumber] = useState('');
  const [cardholderName, setCardholderName] = useState('');
  const [expiryMonth, setExpiryMonth] = useState('');
  const [expiryYear, setExpiryYear] = useState(String(currentYear));
  const [cvv, setCvv] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const months = useMemo(() => Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, '0')), []);
  const years = useMemo(() => Array.from({ length: 12 }, (_, i) => String(currentYear + i)), []);

  if (!open) {
    return null;
  }

  const handlePay = async (event) => {
    event.preventDefault();
    setError('');

    if (!validateCardNumber(cardNumber)) {
      setError('Enter a valid card number');
      return;
    }

    if (!cardholderName.trim()) {
      setError('Cardholder name is required');
      return;
    }

    if (!validateExpiryDate(expiryMonth, expiryYear)) {
      setError('Card is expired');
      return;
    }

    if (!validateCVV(cvv)) {
      setError('Enter a valid CVV');
      return;
    }

    try {
      setLoading(true);
      const result = await processPayment({
        cardNumber,
        cardholderName,
        expiryMonth,
        expiryYear,
        cvv,
        amount,
        description: 'Smart Campus mock payment'
      });
      await onSuccess(result);
    } catch (err) {
      setError(err.message || 'Payment failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
      <div className="w-full max-w-md rounded-xl bg-white p-6 shadow-xl">
        <h3 className="mb-2 text-xl font-semibold text-gray-900">Mock Payment</h3>
        <p className="mb-4 text-sm text-gray-600">Amount: ৳{Number(amount || 0).toFixed(2)}</p>

        {error && (
          <div className="mb-4 rounded-lg border border-accent-200 bg-accent-50 p-3 text-sm text-accent-800">
            {error}
          </div>
        )}

        <form onSubmit={handlePay} className="space-y-3">
          <input
            type="text"
            value={cardNumber}
            onChange={(e) => setCardNumber(e.target.value)}
            placeholder="Card Number (e.g. 4242 4242 4242 4242)"
            className="w-full rounded-lg border border-gray-300 px-3 py-2"
          />
          <input
            type="text"
            value={cardholderName}
            onChange={(e) => setCardholderName(e.target.value)}
            placeholder="Cardholder Name"
            className="w-full rounded-lg border border-gray-300 px-3 py-2"
          />
          <div className="grid grid-cols-3 gap-2">
            <select
              value={expiryMonth}
              onChange={(e) => setExpiryMonth(e.target.value)}
              className="rounded-lg border border-gray-300 px-3 py-2"
            >
              <option value="">MM</option>
              {months.map((month) => (
                <option key={month} value={month}>{month}</option>
              ))}
            </select>
            <select
              value={expiryYear}
              onChange={(e) => setExpiryYear(e.target.value)}
              className="rounded-lg border border-gray-300 px-3 py-2"
            >
              {years.map((year) => (
                <option key={year} value={year}>{year}</option>
              ))}
            </select>
            <input
              type="text"
              value={cvv}
              onChange={(e) => setCvv(e.target.value)}
              placeholder="CVV"
              className="rounded-lg border border-gray-300 px-3 py-2"
            />
          </div>

          <div className="mt-4 flex gap-2">
            <Button type="button" variant="outline" className="flex-1" onClick={onClose} disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" variant="primary" className="flex-1" loading={loading}>
              Pay & Place
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MockPaymentModal;
