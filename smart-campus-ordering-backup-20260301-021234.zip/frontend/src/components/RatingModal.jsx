// src/components/RatingModal.jsx
import { useState } from "react";
import apiClient from "../api/client";

export default function RatingModal({ orderId, onClose }) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");

  const handleSubmit = async () => {
    try {
      await apiClient.post("/ratings", {
        orderId,
        rating,
        comment
      });
      onClose(true); // Close and refresh
    } catch (err) {
      alert("Rating submission failed");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-lg w-96">
        <h2 className="text-xl font-bold mb-4">Rate Your Order</h2>
        <div className="flex mb-4">
          {[1, 2, 3, 4, 5].map((star) => (
            <button 
              key={star}
              onClick={() => setRating(star)}
              className={`text-2xl ${star <= rating ? "text-yellow-400" : "text-gray-300"}`}
            >
              ★
            </button>
          ))}
        </div>
        <textarea
          placeholder="Optional feedback..."
          className="border p-2 w-full mb-4"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />
        <div className="flex justify-end space-x-2">
          <button 
            onClick={() => onClose(false)}
            className="px-4 py-2 border rounded"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!rating}
            className={`px-4 py-2 rounded text-white ${rating ? "bg-blue-500" : "bg-gray-400"}`}
          >
            Submit
          </button>
        </div>
      </div>
    </div>
  );
}
