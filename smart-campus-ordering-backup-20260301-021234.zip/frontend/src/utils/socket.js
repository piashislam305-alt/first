import { io } from 'socket.io-client';

const SOCKET_URL = 'http://localhost:5000'; // Make sure this matches your backend URL

// Initialize the socket connection
const socket = io(SOCKET_URL, {
  autoConnect: true,
  withCredentials: true
});

export default socket;