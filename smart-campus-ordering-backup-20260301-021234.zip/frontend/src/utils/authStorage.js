const TOKEN_KEY = 'smart_campus_token';

export const getAuthTokenWithSource = () => {
  const sessionToken = sessionStorage.getItem(TOKEN_KEY);
  if (sessionToken) {
    return { token: sessionToken, source: 'session' };
  }
  return { token: null, source: null };
};

export const setAuthToken = (token, rememberMe = false) => {
  // Keep auth session tab-scoped to allow different accounts in different tabs.
  void rememberMe;
  sessionStorage.setItem(TOKEN_KEY, token);
  localStorage.removeItem(TOKEN_KEY);
  return 'session';
};

export const clearAuthToken = (source = null) => {
  if (!source || source === 'session' || source === 'local') {
    sessionStorage.removeItem(TOKEN_KEY);
  }
  localStorage.removeItem(TOKEN_KEY);
};

export const getAuthToken = () => getAuthTokenWithSource().token;
