// Helper function to validate CUET email
export const isValidCuetEmail = (email) => {
  const regex = /^[a-zA-Z0-9._-]+@student\.cuet\.ac\.bd$/;
  return regex.test(email);
};

// Helper function to validate password strength
export const isPasswordStrong = (password) => {
  // At least 8 characters, one uppercase, one lowercase, one number
  const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
  return regex.test(password);
};

// Format error message from backend
export const formatErrorMessage = (error) => {
  if (error.response) {
    // The request was made and the server responded with a status code
    return error.response.data.error || error.response.data.message || 'An error occurred';
  } else if (error.request) {
    // The request was made but no response was received
    return 'No response from server. Please try again later.';
  } else {
    // Something happened in setting up the request
    return error.message || 'An unexpected error occurred';
  }
};