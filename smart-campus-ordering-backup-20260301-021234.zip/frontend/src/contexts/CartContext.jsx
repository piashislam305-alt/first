import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

export function useCart() {
  return useContext(CartContext);
}

export function CartProvider({ children }) {
  const [cart, setCart] = useState(() => {
    const savedCart = sessionStorage.getItem('cart');
    return savedCart ? JSON.parse(savedCart) : [];
  });
  const [vendorId, setVendorId] = useState(() => sessionStorage.getItem('cartVendorId'));

  useEffect(() => {
    sessionStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    if (vendorId) {
      sessionStorage.setItem('cartVendorId', vendorId);
    } else {
      sessionStorage.removeItem('cartVendorId');
    }
  }, [vendorId]);

  const addToCart = (item) => {
    if (!vendorId && item.vendorId) {
      setVendorId(String(item.vendorId));
    }

    setCart(prevCart => {
      const existingItem = prevCart.find(cartItem => cartItem._id === item._id);
      
      if (existingItem) {
        return prevCart.map(cartItem =>
          cartItem._id === item._id
            ? { ...cartItem, quantity: cartItem.quantity + 1 }
            : cartItem
        );
      } else {
        return [...prevCart, { ...item, quantity: 1 }];
      }
    });
  };

  const removeFromCart = (itemId) => {
    setCart(prevCart => prevCart.filter(item => item._id !== itemId));
  };

  const updateQuantity = (itemId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }
    
    setCart(prevCart =>
      prevCart.map(item =>
        item._id === itemId ? { ...item, quantity } : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
    setVendorId(null);
    sessionStorage.removeItem('cart');
    sessionStorage.removeItem('cartVendorId');
  };

  const setVendor = (id) => {
    const nextVendorId = id ? String(id) : null;
    setVendorId((prev) => (prev === nextVendorId ? prev : nextVendorId));
  };

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const value = {
    cart,
    vendorId,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    setVendor,
    totalItems,
    totalPrice
  };

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
}
