import React, { createContext, useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { login as loginAPI, register as registerAPI, getCurrentUser } from '../api/auth';
import { clearAuthToken, getAuthTokenWithSource, setAuthToken } from '../utils/authStorage';
import { disconnectSocket } from '../services/socketService';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [tokenSource, setTokenSource] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const { token, source } = getAuthTokenWithSource();
    if (token) {
      setTokenSource(source);
      fetchUser(source);
    } else {
      setLoading(false);
    }
  }, []);

  const fetchUser = async (sourceOverride = tokenSource) => {
    try {
      const user = await getCurrentUser();
      setCurrentUser(user);
    } catch (error) {
      console.error('Failed to fetch user', error);
      clearAuthToken(sourceOverride);
      setTokenSource(null);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password, options = {}) => {
    try {
      const response = await loginAPI(email, password);
      const { token, user } = response;

      const source = setAuthToken(token, Boolean(options.rememberMe));
      setTokenSource(source);
      setCurrentUser(user);

      // Redirect based on role
      if (user.role === 'student') {
        navigate('/student');
      } else if (user.role === 'vendor') {
        navigate('/vendor');
      } else if (user.role === 'admin') {
        navigate('/admin');
      }
      
      return true;
    } catch (error) {
      console.error('Login failed', error);
      return false;
    }
  };

  const register = async (email, password, role, additionalData) => {
    try {
      const response = await registerAPI(email, password, role, additionalData);
      const { token, user } = response;

      const source = setAuthToken(token, false);
      setTokenSource(source);
      setCurrentUser(user);

      // Redirect based on role
      if (role === 'student') {
        navigate('/student');
      } else if (role === 'vendor') {
        navigate('/vendor');
      }
      
      return true;
    } catch (error) {
      console.error('Registration failed', error);
      return false;
    }
  };

  const logout = () => {
    clearAuthToken(tokenSource);
    setTokenSource(null);
    setCurrentUser(null);
    disconnectSocket();
    navigate('/login');
  };

  const value = {
    currentUser,
    login,
    register,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}
