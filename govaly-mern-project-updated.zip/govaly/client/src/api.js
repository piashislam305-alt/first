import axios from 'axios';
import storage from './storage.js';

const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use((config) => {
  const token = storage.get('govaly_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

let refreshing = null;

api.interceptors.response.use(
  (r) => r,
  async (err) => {
    const original = err.config || {};
    const status = err.response?.status;

    if (status === 401 && !original._retry && !String(original.url || '').includes('/auth/')) {
      original._retry = true;
      try {
        // One transparent attempt to renew the session via refresh token
        refreshing ||= axios.post('/api/auth/refresh', {
          refreshToken: storage.get('govaly_refresh'),
        });
        const { data } = await refreshing;
        refreshing = null;
        storage.set('govaly_token', data.accessToken);
        if (data.refreshToken) storage.set('govaly_refresh', data.refreshToken);
        original.headers = original.headers || {};
        original.headers.Authorization = `Bearer ${data.accessToken}`;
        return api(original);
      } catch {
        refreshing = null;
        storage.remove('govaly_token');
        storage.remove('govaly_refresh');
        window.dispatchEvent(new Event('govaly:logout'));
      }
    }
    throw err;
  }
);

export const errMsg = (e, fallback = 'Something went wrong') =>
  e?.response?.data?.message || e?.message || fallback;

export default api;
