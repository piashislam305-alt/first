import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api.js';
import ProductCard from '../components/ProductCard.jsx';
import { Spinner } from '../components/ui.jsx';

/* SRS customer home — simplified:
   ✅ sub-category cards (Women's Footwear, Men's Shoes, Kids' Shoes …) from DB
   ✅ product browsing tabs (For You / Men / Women / Kids / Baby / Health & Beauty)
   ❌ no hero, no USP strip, no top brands, no exclusive/promo deals, no flash sale, no campaigns */

const TABS = [
  { key: '', label: 'For You' },
  { key: 'men', label: 'Men' },
  { key: 'women', label: 'Women' },
  { key: 'kids', label: 'Kids' },
  { key: 'baby', label: 'Baby' },
  { key: 'health-beauty', label: 'Health & Beauty' },
];

function ShopByCategory() {
  const [subs, setSubs] = useState(null);

  useEffect(() => {
    api.get('/categories')
      .then(({ data }) => {
        const all = data.categories || [];
        setSubs(all.filter((c) => !c.isParent));
      })
      .catch(() => setSubs([]));
  }, []);

  if (!subs) return <Spinner />;
  if (!subs.length) return null;

  return (
    <section className="section container">
      <h3 className="sec-title" style={{ marginBottom: 12 }}>Shop by Category</h3>
      <div className="cat-scroll" style={{ flexWrap: 'wrap' }}>
        {subs.map((c) => (
          <Link className="cat-item" to={`/category/${c.slug}`} key={c.slug}>
            <span className="cat-imgwrap">
              <img src={c.image || '/favicon.svg'} alt={c.name} loading="lazy" />
            </span>
            <span>{c.name}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

function ProductTabs() {
  const [tab, setTab] = useState('');
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    api
      .get('/products', { params: { group: tab || undefined, limit: 12, sort: 'popular' } })
      .then(({ data }) => setItems(data.items))
      .catch(() => setItems([]))
      .finally(() => setLoading(false));
  }, [tab]);

  return (
    <section className="section container" style={{ paddingBottom: 6 }}>
      <div className="tabs">
        {TABS.map((t) => (
          <button key={t.key} className={`tab${tab === t.key ? ' on' : ''}`} onClick={() => setTab(t.key)}>
            {t.label}
          </button>
        ))}
      </div>
      {loading ? (
        <Spinner />
      ) : (
        <div className="grid">
          {items.map((p) => <ProductCard p={p} key={p._id} compact />)}
        </div>
      )}
      <div className="center" style={{ padding: '2px 0 18px' }}>
        <Link className="btn btn-outline btn-sm" to={`/products${tab ? `?group=${tab}` : ''}`}>View All Products →</Link>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <>
      <ShopByCategory />
      <ProductTabs />
    </>
  );
}
